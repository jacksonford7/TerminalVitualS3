﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Globalization;
using BillionEntidades;
using N4;
using N4Ws;
using N4Ws.Entidad;
using System.Xml.Linq;
using System.Xml;
using Salesforces;
using System.Data;
using System.Net;
using SqlConexion;
using CasManual;

using System.Reflection;
using System.ComponentModel;
using VBSEntidades.Plantilla;
using VBSEntidades;
using VBSEntidades.ClaseEntidades;
using System.Web.Services;
using VBSEntidades.Calendario;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using Newtonsoft.Json;
using ProcesaUnits;
using VBSEntidades.Banano;
using BreakBulk;
using VBSEntidades.BananoMuelle;

namespace CSLSite
{
    public partial class VBS_BAN_Calendario_Edit : System.Web.UI.Page
    {

        #region "Clases"

        private Cls_Bil_Sesion objSesion = new Cls_Bil_Sesion();
        usuario ClsUsuario;

        private string cMensajes;
        //BAN_CabeceraPlantilla objPlantilla = new BAN_CabeceraPlantilla();
        //VBS_TurnosDetalle _objTurnos = new VBS_TurnosDetalle();
        //List<VBS_TurnosDetalle> ListTurnos = new List<VBS_TurnosDetalle>();
        BAN_CabeceraPlantilla objPlantilla = new BAN_CabeceraPlantilla();
        BAN_TurnosCab objCabecera = new BAN_TurnosCab();
        BAN_TurnosDet _objTurnos = new BAN_TurnosDet();
        List<BAN_TurnosDet> ListTurnos = new List<BAN_TurnosDet>();


        #endregion

        #region "Variables"

        private string LoginName = string.Empty;


        /*variables control de credito*/

        private Cls_Bil_PasePuertaCFS_Cabecera objCas = new Cls_Bil_PasePuertaCFS_Cabecera();
        private Cls_Bil_CasManual objDetalleCas = new Cls_Bil_CasManual();

        private BAN_CabeceraPlantilla objCab = new BAN_CabeceraPlantilla();
        private VBS_DetallePlantilla objDet = new VBS_DetallePlantilla();
        #endregion

        #region "Propiedades"

        private Int64? nSesion
        {
            get
            {
                return (Int64)Session["nSesion"];
            }
            set
            {
                Session["nSesion"] = value;
            }

        }




        #endregion

        #region "Metodos"




        private void OcultarLoading(string valor)
        {
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "ocultarloader('" + valor + "');", true);
        }

        public static string securetext(object number)
        {
            if (number == null)
            {
                return string.Empty;
            }
            return QuerySegura.EncryptQueryString(number.ToString());
        }

        private void Mostrar_Mensaje(int Tipo, string Mensaje)
        {
            if (Tipo == 1)//cabecera
            {
                //      this.banmsg.Visible = true;
                //         this.banmsg.InnerHtml = Mensaje;
                OcultarLoading("1");
            }


        }

        private void Ocultar_Mensaje()
        {
            this.banmsg.InnerText = string.Empty;
            this.banmsg.Visible = false;
            this.Actualiza_Paneles();
            OcultarLoading("1");
            OcultarLoading("2");

        }


        private void Crear_Sesion()
        {
            objSesion.USUARIO_CREA = ClsUsuario.loginname;
            objPlantilla.IV_USUARIO_CREA = ClsUsuario.nombres + "-" + ClsUsuario.apellidos;
            nSesion = objSesion.SaveTransaction(out cMensajes);
            if (!nSesion.HasValue || nSesion.Value <= 0)
            {
                this.Mostrar_Mensaje(2, string.Format("<b>Error! No se pudo generar el id de la sesión, por favor comunicarse con el departamento de IT de CGSA... {0}</b>", cMensajes));
                return;
            }


            //cabecera de transaccion

            objPlantilla = new BAN_CabeceraPlantilla();
            Session["Plantilla" + this.hf_BrowserWindowName.Value] = objPlantilla;

            _objTurnos = new BAN_TurnosDet();
            Session["ListTurnos" + this.hf_BrowserWindowName2.Value] = _objTurnos;
        }

        #endregion


        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            ViewStateUserKey = Session.SessionID;
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Page.SslOn();
            }

            if (!Request.IsAuthenticated)
            {
                Response.Redirect("../login.aspx", false);

                return;
            }

            this.IsAllowAccess();
            this.banmsg.Visible = IsPostBack;

            if (!Page.IsPostBack)
            {
                this.banmsg.InnerText = string.Empty;

                ClsUsuario = Page.Tracker();
                if (ClsUsuario != null)
                {
                    this.Txtcliente.Text = string.Format("{0} {1}", ClsUsuario.nombres, ClsUsuario.apellidos);
                    this.Txtruc.Text = string.Format("{0}", ClsUsuario.ruc);
                    this.Txtempresa.Text = string.Format("{0}", ClsUsuario.codigoempresa);
                }

                this.txtNave.Text = string.Empty;
                this.TXTMRN.Text = string.Empty;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    ClsUsuario = usuario.Deserialize(HttpContext.Current.Session["control"].ToString());
                    this.Crear_Sesion();
                    this.Carga_CboBloques();
                    this.Carga_cboHorarioInicials();
                    this.Carga_Lineas();
                    objCabecera.Detalle = ListTurnos;
                }
                
                string horarioInicialId = Request.QueryString["horarioInicialId"];

                // Verificar si el parámetro tiene un valor válido y llamar a FiltrarDatosSegundoDropdown
                if (!string.IsNullOrEmpty(horarioInicialId))
                {
                    int idCarga = int.Parse(horarioInicialId);
                    FiltrarDatosSegundoDropdown(idCarga);
                }
            }
            catch (Exception ex)
            {
                this.Mostrar_Mensaje(1, string.Format("<b>Error! </b>{0}", ex.Message));
            }
        }

        private void FiltrarDatosSegundoDropdown(int idCarga)
        {
            try
            {
                List<BAN_HorarioFinal> ListadoFiltrado = BAN_HorarioFinal.ConsultarHorarioFinal(out cMensajes);

                var list = ListadoFiltrado.Where(x => x.Id_HorarioIni == idCarga).ToList();

                // Crear una cadena de texto con los elementos del DropDownList
                StringBuilder sb = new StringBuilder();
                foreach (var item in list)
                {
                    sb.AppendFormat("<option value=\"{0}\">{1}</option>", item.Id_Hora, item.Desc_Hora);
                }

                // Generar la respuesta como cadena de texto
                string response = sb.ToString();

                // Enviar la respuesta al cliente
                Response.Write(response);
                Response.End();
            }
            catch (Exception ex)
            {
                var t = this.getUserBySesion();
                string Error = string.Format("Ha ocurrido un problema, por favor repórtelo con este código E00-{0}, gracias por entender.", csl_log.log_csl.save_log<Exception>(ex, "consulta", "FiltrarDatosSegundoDropdown", "Hubo un error al filtrar datos", t.loginname));
                this.Mostrar_Mensaje(1, Error);
            }
        }


        //private void Carga_CboTipoCargas()
        //{
        //    try
        //    {
        //        List<VBS_ConsultarTipoCargas> Listado = VBS_ConsultarTipoCargas.ConsultarTipoCargas(out cMensajes);

        //        var idcarga = Listado.FirstOrDefault().Id_Carga;

        //        Carga_CboTipoContenedor(idcarga);
        //        this.cboTipoCarga.DataSource = Listado;
        //        this.cboTipoCarga.DataTextField = "Desc_Carga";
        //        this.cboTipoCarga.DataValueField = "Id_Carga";
        //        this.cboTipoCarga.DataBind();

        //    }
        //    catch (Exception ex)
        //    {
        //        var t = this.getUserBySesion();
        //        string Error = string.Format("Ha ocurrido un problema, por favor repórtelo con este código E00-{0}, gracias por entender.", csl_log.log_csl.save_log<Exception>(ex, "consulta", "Carga_CboTipoCargas", "Hubo un error al cargar Tipo de cargas", t.loginname));
        //        this.Mostrar_Mensaje(1, Error);
        //    }
        //}

        private void Carga_CboBloques()
        {
            try
            {
                List<VBS_ConsultarTipoBloques> Listado = VBS_ConsultarTipoBloques.ConsultarTipoBloques(out cMensajes);


                this.cboBloque.DataSource = Listado;
                this.cboBloque.DataTextField = "Codigo";
                this.cboBloque.DataValueField = "IdBloque";
                this.cboBloque.DataBind();

            }
            catch (Exception ex)
            {
                var t = this.getUserBySesion();
                string Error = string.Format("Ha ocurrido un problema, por favor repórtelo con este código E00-{0}, gracias por entender.", csl_log.log_csl.save_log<Exception>(ex, "consulta", "Carga_CboTipoCargas", "Hubo un error al cargar Tipo de cargas", t.loginname));
                this.Mostrar_Mensaje(1, Error);
            }
        }

        [WebMethod]
        public static string GetCalendarEvents(int year, int month, bool inicial, string referencia, int op)
        {
            if (string.IsNullOrEmpty(referencia))
            {
                return null;
            }
            List<BAN_EventoCalendario> eventos = new List<BAN_EventoCalendario>();

            BAN_CabeceraPlantilla objPlantilla1 = new BAN_CabeceraPlantilla();
            var detalles = objPlantilla1.GetListaCalendario(year, month, referencia);

            try
            {
                //if (inicial)
                {
                    if (month == 12)
                    {
                        year = year + 1;
                        month = 1;
                    }
                    else
                    {
                        month = month + 1;
                    }

                    var detalles1 = objPlantilla1.GetListaCalendario(year, month,referencia);

                    if (detalles1.Exitoso)
                    {
                        if (!detalles.Exitoso)
                        {
                            detalles = detalles1;
                        }
                        else
                        {
                            detalles.Resultado.AddRange(detalles1.Resultado);
                        }
                    }
                }
            }
            catch { }

            if (detalles.Resultado == null)
            {
                return null;
            }
            else
            {
                foreach (BAN_Calendario_Turnos detalle in detalles.Resultado)
                {
                    BAN_EventoCalendario evento = new BAN_EventoCalendario();
                    evento.title = $"{detalle.codLinea} | {detalle.HoraInicial} - {detalle.HoraFinal} - {detalle.Total_Turnos} {"Stock"} ({detalle.Total_Disponibles})"; // Combinar tipo_contenedor y total_turnos
                    evento.start = detalle.Dia.ToString("yyyy-MM-dd");
                    evento.end = detalle.Dia.AddDays(1).ToString("yyyy-MM-dd");
                    evento.idDetalle = int.Parse( detalle.Detalle.ToString());
                    if (detalle.HoraInicialId == 1)
                        evento.color = "#336BFF";
                    if (detalle.HoraInicialId == 2)
                        evento.color = "#17a2b8";
                    if (detalle.HoraInicialId == 3)
                        evento.color = "#dc3545";


                    eventos.Add(evento);
                }

                JavaScriptSerializer serializer = new JavaScriptSerializer();
                string json = serializer.Serialize(eventos.ToArray());
                return json;
            }

        }

        [WebMethod]
        public static string GetCalendarEventsImport(int year, int month, bool inicial, int pageIndex, int pageSize)
        {
            List<BAN_EventoCalendario> eventos = new List<BAN_EventoCalendario>();

            BAN_CabeceraPlantilla objPlantilla1 = new BAN_CabeceraPlantilla();
            var detalles = objPlantilla1.GetListaCalendarioImport(year, month);

            try
            {
                int startIndex = pageIndex * pageSize;
                if (inicial)
                {
                    if (month == 12)
                    {
                        year = year + 1;
                        month = 1;
                    }
                    else
                    {
                        month = month + 1;
                    }

                    var detalles1 = objPlantilla1.GetListaCalendarioImport(year, month);

                    if (detalles1.Exitoso)
                    {
                        if (!detalles.Exitoso)
                        {
                            detalles = detalles1;
                        }
                        else
                        {
                            detalles.Resultado.Clear();
                            detalles.Resultado.AddRange(detalles1.Resultado);
                        }
                    }
                }
                else
                {
                    if (month == 12)
                    {
                        year = year + 1;
                        month = 1;
                    }
                    else
                    {
                        month = month + 1;
                    }

                    var detalles1 = objPlantilla1.GetListaCalendarioImport(year, month);

                    if (detalles1.Exitoso)
                    {
                        if (detalles.Exitoso)
                        {
                            detalles.Resultado.Clear();
                        }

                        detalles = detalles1;
                        //detalles.Resultado.AddRange(detalles1.Resultado);

                    }

                }
            }
            catch { }


            if (detalles.Resultado == null)
            {
                return null;
            }
            else
            {

                var query = detalles.Resultado.Distinct();//  DistinctBy(p => new { p.TypeId, p.Name });

                int startIndex = pageIndex * pageSize;
                var eventosPaginados = query.Skip(startIndex).Take(pageSize);

                foreach (Calendario_Turnos_Import detalle in eventosPaginados)
                {
                    BAN_EventoCalendario evento = new BAN_EventoCalendario();
                    evento.title = $"{detalle.Bloque}  - {detalle.Total_Turnos} Disponible ({detalle.Total_Disponibles})";
                    evento.start = detalle.Dia.ToString("yyyy-MM-dd");
                    evento.end = detalle.Dia.AddDays(1).ToString("yyyy-MM-dd");
                    evento.color = "#336BFF";
                    evento.idDetalle = detalle.idBloque;

                    eventos.Add(evento);
                }

                JavaScriptSerializer serializer = new JavaScriptSerializer();
                string json = serializer.Serialize(eventos.ToArray());
                return json;
            }

        }

        public class Detalle
        {
            public string secuencia { get; set; }
            public string vHorarioFinal { get; set; }
            public string vHorarioInicial { get; set; }
            public string cantidad { get; set; }
            public string categoria { get; set; }
            public string horarioInicialId { get; set; }
            public string horarioFinalId { get; set; }
            public string lineaNavieraId { get; set; }
            public string lineaNaviera { get; set; }
        }

        public class DetalleImport
        {
            public string secuencia { get; set; }
            public string bloqueId { get; set; }
            public string tipoBloque { get; set; }
            public string frecuencia { get; set; }

        }

        [WebMethod]
        public static string GuardarDatosTabla1(string vigenciaInicial, string vigenciaFinal, int banderaDayClick, List<Detalle> detalles, string vTxtruc, string vTxtempresa, string vTxtcliente, string vTXTMRN, string vtxtNave, string vtxtDescripcionNave, string vfecETA)
        {
            if (detalles == null)
            {
                throw new ArgumentNullException(nameof(detalles));
            }

            try
            {
                var ClsUsuario = usuario.Deserialize(HttpContext.Current.Session["control"].ToString());
                string fechaFormateadaInicial = string.Empty;
                string fechaFormateadaFinal = string.Empty;
                VBS_BAN_Calendario_Edit pageCalendario = new VBS_BAN_Calendario_Edit();
                if (banderaDayClick == 0)
                {
                    string formato = "ddd MMM dd yyyy HH:mm:ss 'GMT'zzz";
                    DateTimeOffset fechaVigenciaInicial = DateTimeOffset.ParseExact(vigenciaInicial, formato, CultureInfo.InvariantCulture);
                    DateTimeOffset fechaVigenciaFinal = DateTimeOffset.ParseExact(vigenciaFinal, formato, CultureInfo.InvariantCulture);

                    fechaVigenciaFinal = fechaVigenciaFinal.AddDays(-1);

                    fechaFormateadaInicial = fechaVigenciaInicial.ToString("yyyy-MM-dd");
                    fechaFormateadaFinal = fechaVigenciaFinal.ToString("yyyy-MM-dd");
                }
                else
                {
                    fechaFormateadaInicial = vigenciaInicial;
                    fechaFormateadaFinal = vigenciaFinal;
                }
                //#############################
                //VALIDA DATOS DE LA NAVE
                //#############################
                try
                {
                    var oNave = nave.GetNave(vtxtNave);
                    vtxtDescripcionNave = oNave.name;
                    vfecETA = oNave.published_eta.ToString("dd/MM/yyyy");
                    vTXTMRN = oNave.in_customs_voy_nbr;
                }
                catch { }

                BAN_TurnosCab oTurnoCab = new BAN_TurnosCab();
                BAN_CabeceraPlantilla objCabPlantilla = new BAN_CabeceraPlantilla();
                objCabPlantilla.FECHA_CREACION = DateTime.Now;
                objCabPlantilla.ESTADO = true;
                objCabPlantilla.NOMBRE_PLANTILLA = ClsUsuario.nombres + "-" + ClsUsuario.apellidos;
                objCabPlantilla.VIGENCIA_INICIAL = Convert.ToDateTime(fechaFormateadaInicial);
                objCabPlantilla.VIGENCIA_FINAL = Convert.ToDateTime(fechaFormateadaFinal);
                objCabPlantilla.USUARIO_CREACION = ClsUsuario.nombres + "-" + ClsUsuario.apellidos;

                oTurnoCab.id = 0;
                oTurnoCab.idAgente = vTxtruc;
                oTurnoCab.Agente = vTxtempresa + " - " + vTxtcliente;
                oTurnoCab.mrn = vTXTMRN;
                oTurnoCab.idNave = vtxtNave;
                oTurnoCab.nave = vtxtDescripcionNave;
                DateTime fecha = new DateTime();
                CultureInfo enUS = new CultureInfo("en-US");
                if (!DateTime.TryParseExact(vfecETA, "dd/MM/yyyy", enUS, DateTimeStyles.None, out fecha))
                {
                    //this.Alerta(string.Format("EL FORMATO DE FECHA ETA DEBE SER dia/Mes/Anio {0}", vfecETA.Text));
                    //fecETA.Focus();
                    //return;
                    throw new Exception(string.Format("EL FORMATO DE FECHA ETA DEBE SER dia/Mes/Anio {0}", vfecETA));
                }
                oTurnoCab.eta = fecha;
                oTurnoCab.fecha = DateTime.Now;
                oTurnoCab.estado = true;

                try
                {
                    var ClsUsuario_ = usuario.Deserialize(HttpContext.Current.Session["control"].ToString());
                    ClsUsuario = ClsUsuario_;
                }
                catch (Exception ex)
                {
                    //Response.Redirect("../login.aspx", false);
                    //return;
                    return "Sesión caducada: " + ex.Message;
                }
                oTurnoCab.usuarioCrea = ClsUsuario.loginname;

                oTurnoCab.Detalle = null;
                objCabPlantilla.TurnoCab = oTurnoCab;

                System.Xml.Linq.XDocument XMLTurnos = new System.Xml.Linq.XDocument(new System.Xml.Linq.XDeclaration("1.0", "UTF-8", "yes"),
                    new System.Xml.Linq.XElement("TURNOS", from p in detalles.AsEnumerable().AsParallel()
                                                           select new System.Xml.Linq.XElement("DETALLE",
                                                           new System.Xml.Linq.XAttribute("SECUENCIA", p.secuencia),
                                                           new System.Xml.Linq.XAttribute("FECHA_CREACION", DateTime.Now),
                                                           new System.Xml.Linq.XAttribute("HORARIO_INICIAL_ID", p.horarioInicialId),
                                                           new System.Xml.Linq.XAttribute("HORARIO_INICIAL", p.vHorarioInicial),
                                                           new System.Xml.Linq.XAttribute("HORARIO_FINAL_ID", p.horarioFinalId),
                                                           new System.Xml.Linq.XAttribute("HORARIO_FINAL", p.vHorarioFinal),
                                                           new System.Xml.Linq.XAttribute("CANTIDAD", p.cantidad),
                                                           new System.Xml.Linq.XAttribute("ESTADO", 1),
                                                           new System.Xml.Linq.XAttribute("VIGENCIA_INICIAL", fechaFormateadaInicial),
                                                           new System.Xml.Linq.XAttribute("VIGENCIA_FINAL", fechaFormateadaFinal),
                                                           new System.Xml.Linq.XAttribute("LINEA_ID", p.lineaNavieraId),
                                                           new System.Xml.Linq.XAttribute("LINEA_NAVIERA", p.lineaNaviera),
                                                           new System.Xml.Linq.XAttribute("flag", "I"))));
                objCabPlantilla.xmlTurnos = XMLTurnos.ToString();

                var _cMensajes = String.Empty;

                var nProceso = objCabPlantilla.SaveTransaction(out _cMensajes);
                                
                var consultarTurnosGenerados = objCabPlantilla.DetallePlantillas("", Convert.ToInt32(nProceso));

                List<BAN_NombrePlantillas> oDetalle = new List<BAN_NombrePlantillas>();

                if (consultarTurnosGenerados.Resultado != null)
                {
                    BAN_TurnosDet oTurnoDet = new BAN_TurnosDet();
                    foreach (var ListDetalle in consultarTurnosGenerados.Resultado)
                    {
                        var consultaTurnosDetalle = oTurnoDet.VerificarCombinacionTipoCargaContenedor(ListDetalle.IDHORAFINAL, ListDetalle.IDHORAINICIAL, vigenciaInicial);

                        if (consultaTurnosDetalle.Resultado == null)
                        {
                            var Transportista = oTurnoDet.GuardarTurnos(Convert.ToInt32(nProceso),
                                ListDetalle.ID_DETALLEPLANTILLA,
                                ListDetalle.IDHORAFINAL,
                                ListDetalle.HORAFINAL,
                                ListDetalle.IDHORAINICIAL,
                                ListDetalle.HORAINICIAL,
                                ListDetalle.CANTIDAD,
                                ListDetalle.CATEGORIA,
                                ClsUsuario.nombres + "-" + ClsUsuario.apellidos,
                                Convert.ToDateTime(fechaFormateadaInicial),
                                Convert.ToDateTime(fechaFormateadaFinal),
                                ListDetalle.IDLINEA,
                                ListDetalle.LINEANAVIERA);

                            oDetalle = Transportista.Resultado.ToList();
                        }
                    }
                }
                else
                {
                    return "L652 - Error al procesar los detalles: " + _cMensajes;
                }

                if (oDetalle.Count() == consultarTurnosGenerados.Resultado.Count())
                {
                    return "Datos guardados correctamente";
                }
                else
                {
                    return "Datos guardados incompletos: total registrados [" + oDetalle.Count().ToString() + "]";
                }
            }
            catch (Exception ex)
            {
                return "Error al procesar los detalles: " + ex.Message;
            }
        }

        [WebMethod]
        public static string GuardarDatosTablaImport(string vigenciaInicial, string vigenciaFinal, int banderaDayClick, List<DetalleImport> detalles)
        {
            if (detalles == null)
            {
                throw new ArgumentNullException(nameof(detalles));
            }

            try
            {

                var ClsUsuario = usuario.Deserialize(HttpContext.Current.Session["control"].ToString());
                string fechaFormateadaInicial = string.Empty;
                string fechaFormateadaFinal = string.Empty;
                VBS_Calendario_Edit pageCalendario = new VBS_Calendario_Edit();
                if (banderaDayClick == 0)
                {
                    string formato = "ddd MMM dd yyyy HH:mm:ss 'GMT'zzz";
                    DateTimeOffset fechaVigenciaInicial = DateTimeOffset.ParseExact(vigenciaInicial, formato, CultureInfo.InvariantCulture);
                    DateTimeOffset fechaVigenciaFinal = DateTimeOffset.ParseExact(vigenciaFinal, formato, CultureInfo.InvariantCulture);

                    fechaVigenciaFinal = fechaVigenciaFinal.AddDays(-1);

                    fechaFormateadaInicial = fechaVigenciaInicial.ToString("yyyy-MM-dd");
                    fechaFormateadaFinal = fechaVigenciaFinal.ToString("yyyy-MM-dd");
                }
                else
                {
                    fechaFormateadaInicial = vigenciaInicial;
                    fechaFormateadaFinal = vigenciaFinal;
                }

                BAN_TurnosDet oTurnoDet = new BAN_TurnosDet();

                foreach (var ListDetalle in detalles)
                {

                    var consultarTipoBloqueExiste = oTurnoDet.VerificarCombinacionTipoBloque(Convert.ToInt32(ListDetalle.bloqueId), ListDetalle.tipoBloque, vigenciaInicial);

                    if (consultarTipoBloqueExiste.Resultado == null)
                    {
                        var Transportista = oTurnoDet.GuardarTurnosImport(
                      ListDetalle.bloqueId,
                      ListDetalle.tipoBloque,
                      Convert.ToInt32(ListDetalle.frecuencia),

                      ClsUsuario.nombres + "-" + ClsUsuario.apellidos,
                        Convert.ToDateTime(fechaFormateadaInicial),
                       Convert.ToDateTime(fechaFormateadaFinal));
                    }
                }

                return "Datos guardados correctamente";
            }
            catch (Exception ex)
            {
                return "Error al procesar los detalles: " + ex.Message;
            }
        }

        [WebMethod]
        public static string ConsultarEventos(int idDetalle, string start, string end)
        {
            try
            {
                DateTime fecha = DateTime.ParseExact(end, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                DateTime fechaRestada = fecha.AddDays(-1);
                string fechaRestadaString = fechaRestada.ToString("yyyy-MM-dd");

                BAN_TurnosDet oTurnoDet = new BAN_TurnosDet();
                var consultaTurnosDetalle = oTurnoDet.GetListaTurnosPorFechas(idDetalle, start, fechaRestadaString);


                // Serializar los datos de eventos paginados a JSON
                string jsonEventos = JsonConvert.SerializeObject(consultaTurnosDetalle.Resultado);

                return jsonEventos;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar eventos en el servidor", ex);
            }
        }

        [WebMethod]
        public static string ConsultarEventosImport(int idDetalle, string start, string end)
        {
            try
            {
                DateTime fecha = DateTime.ParseExact(end, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                DateTime fechaRestada = fecha.AddDays(-1);
                string fechaRestadaString = fechaRestada.ToString("yyyy-MM-dd");

                BAN_CabeceraPlantilla objCab = new BAN_CabeceraPlantilla();
                var consultaTurnosDetalle = objCab.GetListaTurnosImportPorFechas(idDetalle, start, fechaRestadaString);

                var serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                serializer.MaxJsonLength = int.MaxValue;
                // Serializar los datos de eventos paginados a JSON
                string jsonEventos = JsonConvert.SerializeObject(consultaTurnosDetalle.Resultado);

                return jsonEventos;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar eventos en el servidor", ex);
            }
        }

        [WebMethod]
        public static string GuardarDatos(List<ActuEvento> datosTabla)
        {
            try
            {

                var ClsUsuario = usuario.Deserialize(HttpContext.Current.Session["control"].ToString());

                BAN_CabeceraPlantilla objCab = new BAN_CabeceraPlantilla();

                System.Xml.Linq.XDocument XMLTurnos = new System.Xml.Linq.XDocument(new System.Xml.Linq.XDeclaration("1.0", "UTF-8", "yes"),
                    new System.Xml.Linq.XElement("TURNOS", from p in datosTabla.AsEnumerable().AsParallel()
                                                           select new System.Xml.Linq.XElement("DETALLE",
                                                           new System.Xml.Linq.XAttribute("IDTURNO", Convert.ToInt64(p.idTurno)),
                                                           new System.Xml.Linq.XAttribute("CANTIDAD", p.cantidad),
                                                           new System.Xml.Linq.XAttribute("FECHAACTU", DateTime.Now),
                                                           new System.Xml.Linq.XAttribute("USUARIOMODIFI", ClsUsuario.nombres + "-" + ClsUsuario.apellidos),

                                                           new System.Xml.Linq.XAttribute("DISPONIBLE", p.disponible),

                                                           new System.Xml.Linq.XAttribute("ASIGNADOS", p.asignados),
                                                           new System.Xml.Linq.XAttribute("flag", "I"))));
                objCab.xmlTurnos = XMLTurnos.ToString();

                var _cMensajes = String.Empty;

                var nProceso = objCab.SaveTransactionUPDATE(out _cMensajes);
                if (nProceso > 0)
                {

                    return "success";
                }

                return "fail";
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

                return JsonConvert.SerializeObject(new { result = "error" });
            }
        }

        [WebMethod]
        public static string GuardarDatosImport(List<ActuEvento> datosTabla)
        {
            try
            {

                var ClsUsuario = usuario.Deserialize(HttpContext.Current.Session["control"].ToString());

                BAN_CabeceraPlantilla objCab = new BAN_CabeceraPlantilla();

                System.Xml.Linq.XDocument XMLTurnos = new System.Xml.Linq.XDocument(new System.Xml.Linq.XDeclaration("1.0", "UTF-8", "yes"),
                    new System.Xml.Linq.XElement("TURNOS", from p in datosTabla.AsEnumerable().AsParallel()
                                                           select new System.Xml.Linq.XElement("DETALLE",
                                                           new System.Xml.Linq.XAttribute("IDTURNO", Convert.ToInt64(p.idTurno)),
                                                           new System.Xml.Linq.XAttribute("CANTIDAD", p.cantidad),
                                                           new System.Xml.Linq.XAttribute("FECHAACTU", DateTime.Now),
                                                           new System.Xml.Linq.XAttribute("USUARIOMODIFI", ClsUsuario.nombres + "-" + ClsUsuario.apellidos),

                                                           new System.Xml.Linq.XAttribute("DISPONIBLE", p.disponible),

                                                           new System.Xml.Linq.XAttribute("ASIGNADOS", p.asignados),
                                                           new System.Xml.Linq.XAttribute("flag", "I"))));
                objCab.xmlTurnos = XMLTurnos.ToString();

                var _cMensajes = String.Empty;

                var nProceso = objCab.SaveTransactionUPDATEIMPORT(out _cMensajes);
                if (nProceso > 0)
                {

                    return "success";
                }

                return "fail";
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

                return JsonConvert.SerializeObject(new { result = "error" });
            }
        }
       
        [WebMethod]
        public static string ConsultarEventosPorDia(string start)
        {
            try
            {
                BAN_TurnosDet oTurnoDet = new BAN_TurnosDet();
                List<BAN_EventoCalendario> eventos = new List<BAN_EventoCalendario>();
                DateTime fecha = DateTime.ParseExact(start, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                string fechaRestadaString = fecha.ToString("yyyy-MM-dd");
                var consultaTurnosDetalle = oTurnoDet.GetListaTurnosPorDia(fechaRestadaString);

                if (consultaTurnosDetalle.Resultado != null)
                {
                    foreach (BAN_TurnosDet detalle in consultaTurnosDetalle.Resultado)
                    {
                        BAN_EventoCalendario evento = new BAN_EventoCalendario();
                        evento.title = $"{detalle.HoraInicio} - {detalle.HoraFinal} - {detalle.Cantidad} {"Disponible"} - ({detalle.Disponible})"; // Combinar tipo_contenedor y total_turnos
                        evento.start = fechaRestadaString;
                        evento.end = fechaRestadaString;
                        if (detalle.idHoraInicio == "1")
                            evento.color = "#336BFF";
                        if (detalle.idHoraInicio == "2")
                            evento.color = "#17a2b8";
                        if (detalle.idHoraInicio == "3")
                            evento.color = "#dc3545";
                        evento.horario = detalle.Horario.ToString(@"hh\:mm");
                        eventos.Add(evento);
                    }
                }

                JavaScriptSerializer serializer = new JavaScriptSerializer();
                string json = serializer.Serialize(eventos.ToArray());

                // Serializar los datos de eventos paginados a JSON
                return json;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar eventos en el servidor", ex);
            }
        }

        [WebMethod]
        public static string ConsultarEventosPorDiaImport(string start)
        {
            try
            {

                List<BAN_EventoCalendario> eventos = new List<BAN_EventoCalendario>();


                DateTime fecha = DateTime.ParseExact(start, "yyyy-MM-dd", CultureInfo.InvariantCulture);

                string fechaRestadaString = fecha.ToString("yyyy-MM-dd");

                BAN_CabeceraPlantilla objCab = new BAN_CabeceraPlantilla();
                var consultaTurnosDetalle = objCab.GetListaTurnosPorDiaImport(fechaRestadaString);

                if (consultaTurnosDetalle.Resultado != null)
                {
                    foreach (VBS_TurnosDetalle_Import detalle in consultaTurnosDetalle.Resultado)
                    {
                        BAN_EventoCalendario evento = new BAN_EventoCalendario();
                        evento.title = $"{detalle.CodigoBloque}  - {detalle.Cantidad} {"Disponible"} - ({detalle.Disponible})"; // Combinar tipo_contenedor y total_turnos
                        evento.start = fechaRestadaString;
                        evento.end = fechaRestadaString;
                        evento.color = "#336BFF";

                        evento.horario = detalle.Horario.ToString(@"hh\:mm");

                        eventos.Add(evento);
                    }

                }


                JavaScriptSerializer serializer = new JavaScriptSerializer();
                string json = serializer.Serialize(eventos.ToArray());

                // Serializar los datos de eventos paginados a JSON

                return json;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar eventos en el servidor", ex);
            }
        }

        [WebMethod]
        public static string ConsultarBookingCalendario(string fecha)
        {
            try
            {
                DataHelper obj = new DataHelper();

                var tablaNave = obj.GetTablaNaves(fecha);
                string jsonTablaNave = ConvertDataTableToJson(tablaNave);
                return jsonTablaNave;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar eventos en el servidor", ex);
            }
        }

        public static string ConvertDataTableToJson(DataTable dataTable)
        {
            string json = JsonConvert.SerializeObject(dataTable, Newtonsoft.Json.Formatting.Indented);
            return json;
        }

        [WebMethod]
        public static string ConsultarTablaExpoPorDia(string start)
        {
            try
            {
                List<BAN_EventoCalendario> eventos = new List<BAN_EventoCalendario>();

                DateTime fecha = DateTime.ParseExact(start, "yyyy-MM-dd", CultureInfo.InvariantCulture);

                string fechaRestadaString = fecha.ToString("yyyy-MM-dd");

                BAN_TurnosDet oTurnoDet = new BAN_TurnosDet();
                var consultaTurnosDetalle = oTurnoDet.GetTablaExpoPorDia(fechaRestadaString);

                if (consultaTurnosDetalle.Resultado != null)
                {
                    foreach (BAN_TurnosDet detalle in consultaTurnosDetalle.Resultado)
                    {
                        BAN_EventoCalendario evento = new BAN_EventoCalendario();
                        evento.title = $"{detalle.HoraInicio} - {detalle.HoraFinal} - {detalle.Cantidad} {"Disponible"} - ({detalle.Disponible})"; // Combinar tipo_contenedor y total_turnos
                        evento.start = fechaRestadaString;
                        evento.end = fechaRestadaString;
                        evento.horarioInicial = detalle.HoraInicio;
                        evento.horarioFinal = detalle.HoraFinal;
                        evento.cantidad = detalle.Cantidad;
                        evento.horarioInicialId = detalle.idHoraInicio;
                        evento.horarioFinalId = detalle.idHoraFinal;
                        evento.idLinea = detalle.idLinea;
                        evento.LineaNaviera = detalle.LineaNaviera?.ToString();
                        eventos.Add(evento);
                    }
                }

                JavaScriptSerializer serializer = new JavaScriptSerializer();
                string json = serializer.Serialize(eventos.ToArray());

                // Serializar los datos de eventos paginados a JSON

                return json;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar eventos en el servidor", ex);
            }
        }

        [WebMethod]
        public static string ConsultarTablaImportPorDia(string start)
        {
            try
            {

                List<BAN_EventoCalendario> eventos = new List<BAN_EventoCalendario>();

                DateTime fecha = DateTime.ParseExact(start, "yyyy-MM-dd", CultureInfo.InvariantCulture);

                string fechaRestadaString = fecha.ToString("yyyy-MM-dd");

                BAN_CabeceraPlantilla objCab = new BAN_CabeceraPlantilla();
                var consultaTurnosDetalle = objCab.GetTablaImportPorDia(fechaRestadaString);

                if (consultaTurnosDetalle.Resultado != null)
                {
                    foreach (VBS_TurnosDetalle_Import detalle in consultaTurnosDetalle.Resultado)
                    {
                        BAN_EventoCalendario evento = new BAN_EventoCalendario();
                        evento.title = $"{detalle.CodigoBloque}  - {detalle.Cantidad} {"Disponible"} - ({detalle.Disponible})"; // Combinar tipo_contenedor y total_turnos
                        evento.start = fechaRestadaString;
                        evento.end = fechaRestadaString;
                        evento.cantidad = detalle.Frecuencia;
                        evento.tipoBloqueId = detalle.idBloque;
                        evento.codigoBloque = detalle.CodigoBloque;

                        eventos.Add(evento);
                    }

                }


                JavaScriptSerializer serializer = new JavaScriptSerializer();
                string json = serializer.Serialize(eventos.ToArray());


                return json;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar eventos en el servidor", ex);
            }
        }

        protected void btnLimpiar_Click(object sender, EventArgs e)
        {
            //this.btnGrabar.Attributes["disabled"] = "disabled";
            Limpia_Datos_cliente();
            objCabecera = new BAN_TurnosCab();
            Session["TransaccionBANCab" + this.hf_BrowserWindowName.Value] = objCabecera;
            tablePagination.DataSource = null;
            tablePagination.DataBind();
            this.Ocultar_Mensaje();
            UPDETALLE.Update();
        }

        private void Limpia_Datos_cliente()
        {
            this.TXTMRN.Text = string.Empty;
            this.txtNave.Text = string.Empty;
            this.txtDescripcionNave.Text = string.Empty;
            this.fecETA.Text = string.Empty;

        }

        private void Actualiza_Paneles()
        {
            UPDETALLE.Update();
            UPCAB.Update();
        }

        private void Mostrar_Mensaje(string Mensaje)
        {
            this.banmsg.Visible = true;
            this.banmsg.InnerHtml = Mensaje;
            OcultarLoading("1");
            OcultarLoading("2");

            this.Actualiza_Paneles();
        }

        protected void ValidarDatosNave()
        {
            try
            {
                var oNave = nave.GetNave(txtNave.Text);
                txtDescripcionNave.Text = oNave.name;
                fecETA.Text = oNave.published_eta.ToString("dd/MM/yyyy");
                TXTMRN.Text = oNave.in_customs_voy_nbr;
                UPCAB.Update();
            }
            catch { }

        }

        private void Carga_cboHorarioInicials()
        {
            try
            {
                List<BAN_HorarioInicial> Listado = BAN_HorarioInicial.ConsultarHorariosIniciales(out cMensajes);

                var idhora = Listado.FirstOrDefault().Id_Hora;

                Carga_CboHorarioFinal(idhora);
                this.cboHorarioInicial.DataSource = Listado;
                this.cboHorarioInicial.DataTextField = "Desc_Hora";
                this.cboHorarioInicial.DataValueField = "Id_Hora";
                this.cboHorarioInicial.DataBind();

            }
            catch (Exception ex)
            {
                var t = this.getUserBySesion();
                string Error = string.Format("Ha ocurrido un problema, por favor repórtelo con este código E00-{0}, gracias por entender.", csl_log.log_csl.save_log<Exception>(ex, "consulta", "Carga_cboHorarioInicials", "Hubo un error al cargar Tipo de cargas", t.loginname));
                this.Mostrar_Mensaje(1, Error);
            }
        }

        private void Carga_CboHorarioFinal(int idcarga)
        {
            try
            {
                List<BAN_HorarioFinal> Listado = BAN_HorarioFinal.ConsultarHorarioFinal(out cMensajes);

                var list = Listado.Where(x => x.Id_HorarioIni == idcarga).ToList();

                this.cboHorarioFinal.DataSource = list;
                this.cboHorarioFinal.DataTextField = "Desc_Hora";
                this.cboHorarioFinal.DataValueField = "Id_Hora";
                this.cboHorarioFinal.DataBind();
            }
            catch (Exception ex)
            {
                var t = this.getUserBySesion();
                string Error = string.Format("Ha ocurrido un problema, por favor repórtelo con este código E00-{0}, gracias por entender.", csl_log.log_csl.save_log<Exception>(ex, "consulta", "Carga_CboHorarioFinal", "Hubo un error al cargar Tipo Contenedor", t.loginname));
                this.Mostrar_Mensaje(1, Error);
            }
        }

        private void Carga_Lineas()
        {
            try
            {
                List<BAN_LineaNaviera> Listado = BAN_LineaNaviera.ConsultarListaLineas(out cMensajes);

                this.cmbLineaNaviera.DataSource = Listado;
                this.cmbLineaNaviera.DataTextField = "linea";
                this.cmbLineaNaviera.DataValueField = "id";
                this.cmbLineaNaviera.DataBind();
            }
            catch (Exception ex)
            {
                var t = this.getUserBySesion();
                string Error = string.Format("Ha ocurrido un problema, por favor repórtelo con este código E00-{0}, gracias por entender.", csl_log.log_csl.save_log<Exception>(ex, "consulta", "Carga_CboTipoContenedor", "Hubo un error al cargar Tipo Contenedor", t.loginname));
                this.Mostrar_Mensaje(1, Error);
            }
        }
    }
}