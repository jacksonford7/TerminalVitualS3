﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using CSLSite.N4Object;
using ConectorN4;
using System.Globalization;
using VBSEntidades;
using VBSEntidades.ClaseEntidades;
using System.Web.Script.Serialization;
using VBSEntidades.Calendario;
using System.Web.Services;
using Newtonsoft.Json;

namespace CSLSite
{
    public partial class consulta : System.Web.UI.Page
    {
        private string _Id_Opcion_Servicio = string.Empty;

        //AntiXRCFG
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            ViewStateUserKey = Session.SessionID;
        }
        protected void Page_Init(object sender, EventArgs e)
        {
            this.IsAllowAccess();
            Page.Tracker();
            if (!IsPostBack)
            {
                this.IsCompatibleBrowser();
                Page.SslOn();

                //para que puedar dar click en el titulo de la pantalla y regresar al menu principal de la zona
                //_Id_Opcion_Servicio = Request.QueryString["opcion"];
                //this.opcion_principal.InnerHtml = string.Format("<a href=\"../cuenta/subopciones.aspx?opcion={0}\">{1}</a>", _Id_Opcion_Servicio, "AISV"); ;

            }
            this.booking.Text = Server.HtmlEncode(this.booking.Text);
            this.aisvn.Text = Server.HtmlEncode(this.aisvn.Text);
            this.cntrn.Text = Server.HtmlEncode(this.cntrn.Text);
            this.docnum.Text = Server.HtmlEncode(this.docnum.Text);
            this.desded.Text = Server.HtmlEncode(this.desded.Text);
            this.desded.Text = Server.HtmlEncode(this.hastad.Text);
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Response.IsClientConnected)
            {
                xfinder.Visible = IsPostBack;
                sinresultado.Visible = false;
            }
        }
        protected void btbuscar_Click(object sender, EventArgs e)
        {
            if (Response.IsClientConnected)
            {
                try
                {
                    if (HttpContext.Current.Request.Cookies["token"] == null)
                    {
                        System.Web.Security.FormsAuthentication.SignOut();
                        System.Web.Security.FormsAuthentication.RedirectToLoginPage();
                        Session.Clear();
                        return;
                    }
                    populate();
                }
                catch (Exception ex)
                {
                    var t = this.getUserBySesion();
                    sinresultado.Attributes["class"] = string.Empty;
                    sinresultado.Attributes["class"] = "msg-critico";
                    sinresultado.InnerText = string.Format("Ha ocurrido un problema durante la búsqueda, por favor repórtelo con este código E00-{0}, gracias por entender.", csl_log.log_csl.save_log<Exception>(ex, "consulta", "btbuscar_Click", "Hubo un error al buscar", t.loginname));
                    sinresultado.Visible = true;
                }
            }
        }
        public static string anulado(object estado)
        {
            if (estado == null)
            {
                return "<span>sin estado!</span>";
            }
            if (estado.ToString().ToLower() == "r")
            {
                return "<span>Registrado</span>";
            }
            if (estado.ToString().ToLower() == "a")
            {
                return "<span class='red' >Anulado</span>";
            }
            if (estado.ToString().ToLower() == "i")
            {
                return "<span class='azul' >Ingresado</span>";
            }
            if (estado.ToString().ToLower() == "s")
            {
                return "<span class='naranja' >Salida</span>";
            }
            return "<span>sin estado!</span>";
        }
        public static string boton(object estado)
        {
            return estado.ToString().ToLower() == "r" ? "ver" : "xver";
        }
        public static string tipos(object tipo, object movi)
        {
            if (tipo == null || movi == null)
            {
                return "!error";
            }

            if (tipo.ToString().Trim().Length < 1 || movi.ToString().Trim().Length < 1)
            {
                return "!error";
            }

            if (movi.ToString().Trim() == "E")
            {
                if (tipo.ToString().Trim() == "C")
                {
                    return "Full";
                }
                else
                {
                    return "C. Suelta";
                }
            }
            else
            {
                return "Consolidación";
            }
        }
        public static string securetext(object number)
        {
            if (number == null || number.ToString().Length <= 2)
            {
                return string.Empty;
            }
            return QuerySegura.EncryptQueryString(number.ToString());
        }
        protected void tablePagination_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (Response.IsClientConnected)
            {
                if (e.CommandName == "Anular")
                {
                    try
                    {
                        if (HttpContext.Current.Request.Cookies["token"] == null)
                        {
                            System.Web.Security.FormsAuthentication.SignOut();
                            Session.Clear();
                            System.Web.Security.FormsAuthentication.RedirectToLoginPage();
                            return;
                        }
                        var user = Page.getUserBySesion();
                        if (user == null)
                        {
                            sinresultado.Attributes["class"] = string.Empty;
                            sinresultado.Attributes["class"] = "msg-critico";
                            sinresultado.InnerText = string.Format("Lo sentimos, algo salió mal. Estamos trabajando para solucionarlo lo más pronto posible por favor reporte este código de servicio A01-{0}", csl_log.log_csl.save_log<InvalidOperationException>(new InvalidOperationException("El retorno de usuario es nulo, posiblemente ha caducado"), "consulta", "tablePagination_ItemCommand", "No se pudo obtener usuario", "anónimo"));
                            sinresultado.Visible = true;
                            return;
                        }
                        if (e.CommandArgument == null)
                        {
                            sinresultado.Attributes["class"] = string.Empty;
                            sinresultado.Attributes["class"] = "msg-critico";
                            sinresultado.InnerText = string.Format("Lo sentimos, algo salió mal. Estamos trabajando para solucionarlo lo más pronto posible por favor reporte este código de servicio  A01-{0}.", csl_log.log_csl.save_log<InvalidOperationException>(new InvalidOperationException("CommandArgument=NULL"), "consulta", "tablePagination_ItemCommand", "CommandArgument is NULL", user.loginname));
                            sinresultado.Visible = true;
                            return;
                        }

                        var xpars = e.CommandArgument.ToString().Split(';');
                        if (xpars.Length <= 0 || xpars.Length < 5)
                        {
                            sinresultado.Attributes["class"] = string.Empty;
                            sinresultado.Attributes["class"] = "msg-critico";
                            sinresultado.InnerText = string.Format("Lo sentimos, algo salió mal. Estamos trabajando para solucionarlo lo más pronto posible por favor reporte este código de servicio  A01-{0}", csl_log.log_csl.save_log<InvalidOperationException>(new InvalidOperationException("El arreglo de parametros tiene un número incorrecto de longitud"), "consulta", "tablePagination_ItemCommand", "CommandArgument longitud errada: " + xpars.Length.ToString(), user.loginname));
                            sinresultado.Visible = true;
                            return;
                        }

                        if (string.IsNullOrEmpty(xpars[5]) || xpars[5].ToLower() != "r")
                        {
                            sinresultado.Attributes["class"] = string.Empty;
                            sinresultado.Attributes["class"] = "msg-critico";
                            sinresultado.InnerText = "No se puede anular este AISV ya que su estado ha cambiado, es posible que la carga ya se encuentre patios.";
                            sinresultado.Visible = true;
                            return;
                        }

                        if (jAisvContainer.UnidadEstado(xpars[2]) > 1)
                        {
                            sinresultado.Attributes["class"] = string.Empty;
                            sinresultado.Attributes["class"] = "msg-critico";
                            sinresultado.InnerText = string.Format("No puede anular el AISV {0} ya que la unidad {1}, se encuentra en patios", xpars[0], xpars[2]);
                            sinresultado.Visible = true;
                            return;
                        }
                        string vt = string.Empty;
                        //cancel advice si es unidad
                        if (!string.IsNullOrEmpty(xpars[2]))
                        {
                            if (xpars[2] == "null")
                            {
                                sinresultado.Attributes["class"] = string.Empty;
                                sinresultado.Attributes["class"] = "msg-critico";
                                sinresultado.InnerText = string.Format("Lo sentimos, algo salió mal y no se encontró el contenedor. Estamos trabajando para solucionarlo lo más pronto posible por favor reporte este código de servicio  A01-{0}.", csl_log.log_csl.save_log<InvalidOperationException>(new InvalidOperationException("El registro era de contenedor lleno pero no se encontró la unidad"), "consulta", "tablePagination_ItemCommand", "Contenedor fué nulo", user.loginname));
                                sinresultado.Visible = true;
                                return;
                            }

                            //Validacion 2 -> Obtener la sesión y covetirla a objectsesion
                            var userk = new ObjectSesion();
                            userk.clase = "consulta"; userk.metodo = "tablePagination_ItemCommand";
                            userk.transaccion = "AISV Consulta"; userk.usuario = user.loginname;

                            //aqui era el error.
                            userk.token = HttpContext.Current.Request.Cookies["token"].Value;


                            var referencia_acopio = System.Web.Configuration.WebConfigurationManager.AppSettings["acopio"];
                            if (string.IsNullOrEmpty(referencia_acopio))
                            {
                                referencia_acopio = "CGS2008001";
                            }

                            //SI ES CONTENEDOR O ES CONSOLIDACION
                            if (xpars[3].ToUpper().Contains("C") || xpars[4].ToUpper().Contains("C") || xpars[1].Contains(referencia_acopio))
                            {
                                //si hay unidad o contenedor.
                                if (!string.IsNullOrEmpty(xpars[2]))
                                {
                                    if (jAisvContainer.ConfirmacionPreaviso(xpars[2].Trim()))
                                    {
                                        if (!jAisvContainer.cancelAdvice(userk, xpars[2], xpars[1], out vt))
                                        {
                                            sinresultado.Attributes["class"] = string.Empty;
                                            sinresultado.Attributes["class"] = "msg-critico";
                                            sinresultado.InnerText = string.Format("No se pudo eliminar el registro por la siguiente causa:[{1}], algo salió mal. Código de servicio A01-{0}", csl_log.log_csl.save_log<InvalidOperationException>(new InvalidOperationException(vt), "CancelAdvice", "tablePagination_ItemCommand", vt, user.loginname), vt);
                                            sinresultado.Visible = true;
                                            return;
                                        }
                                    }
                                }
                            }

                        }

                        if (!jAisvContainer.delete(xpars[0], user.loginname, out vt))
                        {
                            sinresultado.Attributes["class"] = string.Empty;
                            sinresultado.Attributes["class"] = "msg-critico";
                            sinresultado.InnerText = vt;
                            sinresultado.Visible = true;
                            return;
                        }





                        //nuevo bloque si el aisv cambió por concurrencia, entonces no se puede anular
                        if (!string.IsNullOrEmpty(vt))
                        {
                            var negativo = 2;
                            if (!int.TryParse(vt, out negativo) || negativo < 0)
                            {
                                sinresultado.Attributes["class"] = string.Empty;
                                sinresultado.Attributes["class"] = "msg-critico";
                                sinresultado.InnerText = "No fúe posible anular este documento, es probable que la carga ya este ingresada o que el transporte ya este fuera de la terminal, confirme con planificación"; ;
                                sinresultado.Visible = true;
                                populate();
                                return;
                            }

                        }
                        sinresultado.Attributes["class"] = string.Empty;
                        sinresultado.Attributes["class"] = "msg-info";
                        sinresultado.InnerText = string.Format("La anulación del AISV  No.{0} ha resultado exitosa.", xpars[0]);
                        sinresultado.Visible = true;
                        populate();
                    }
                    catch (Exception ex)
                    {
                        var t = this.getUserBySesion();
                        sinresultado.Attributes["class"] = string.Empty;
                        sinresultado.Attributes["class"] = "msg-critico";
                        sinresultado.InnerText = string.Format("Ha ocurrido un problema durante la anulación, por favor repórtelo con este código E00-{0}, gracias por entender.", csl_log.log_csl.save_log<Exception>(ex, "consulta", "Item_comand", "Hubo un error al anular", t.loginname));
                        sinresultado.Visible = true;

                    }
                }
            }
        }
        protected string jsarguments(object aisv, object referencia, object unidad, object movimiento, object tipo, object estado)
        {
            return string.Format("{0};{1};{2};{3};{4};{5}", aisv != null ? aisv.ToString().Trim() : "0", referencia != null ? referencia.ToString().Trim() : "na", unidad != null ? unidad.ToString().Trim() : "null", movimiento != null ? movimiento.ToString().Trim() : "x", tipo != null ? tipo.ToString().Trim() : "x", estado);
        }
        public static string set_view()
        {
            var cfgs = HttpContext.Current.Session["parametros"] as List<dbconfig>;
            var cf = cfgs.Where(f => f.config_name.Contains("val_camara")).FirstOrDefault();
            if (cf == null || string.IsNullOrEmpty(cf.config_value) || cf.config_value.Contains("0"))
            {
                return "nover";
            }
            return "";
        }


        public static string refrigeracion(object estado, object temperatura)
        {
            //0.00
            //nuevo si activan la configuracion entonces fluye
            if (estado == null)
            {
                return "<span style='color:Blue;' >No disponible</span>";
            }
            decimal de;
            if (decimal.TryParse(temperatura.ToString(), out de))
            {
                if (de == 0)
                {
                    return "<span style='color:Black;font-weight:bold;'>No requerido</span>";
                }
            }
            if (!estado.ToString().Equals("0"))
            {
                return "<span style='color:Green;font-weight:bold;'>Activo</span>";
            }

            return "<span style='color:Red;font-weight:bold;' >Inactivo</span>";
        }


        private void populate()
        {
            System.Globalization.CultureInfo enUS = new System.Globalization.CultureInfo("en-US");
            Session["resultado"] = null;
            var table = new Catalogos.Listar_AISVDataTable();
            var ta = new CatalogosTableAdapters.Listar_AISVTableAdapter();
            try
            {
                DateTime desde;
                DateTime hasta;
                if (!DateTime.TryParseExact(desded.Text, "dd/MM/yyyy", enUS, DateTimeStyles.None, out desde))
                {
                    xfinder.Visible = false;
                    sinresultado.Attributes["class"] = string.Empty;
                    sinresultado.Attributes["class"] = "msg-info";
                    this.sinresultado.InnerText = "No se encontraron resultados, revise la fecha desde";
                    sinresultado.Visible = true;
                    return;
                }
                if (!DateTime.TryParseExact(hastad.Text, "dd/MM/yyyy", enUS, DateTimeStyles.None, out hasta))
                {
                    xfinder.Visible = false;
                    sinresultado.Attributes["class"] = string.Empty;
                    sinresultado.Attributes["class"] = "msg-info";
                    this.sinresultado.InnerText = "No se encontraron resultados, revise la fecha hasta";
                    sinresultado.Visible = true;
                    return;
                }
                if (desde.Year != hasta.Year)
                {
                    xfinder.Visible = false;
                    sinresultado.Attributes["class"] = string.Empty;
                    sinresultado.Attributes["class"] = "msg-alerta";
                    this.sinresultado.InnerText = "El rango máximo de consulta es de 1 año, gracias por entender.";
                    sinresultado.Visible = true;
                    return;
                }
                TimeSpan ts = desde - hasta;
                // Difference in days.
                if (ts.Days > 30)
                {
                    xfinder.Visible = false;
                    sinresultado.Attributes["class"] = string.Empty;
                    sinresultado.Attributes["class"] = "msg-alerta";
                    this.sinresultado.InnerText = "El rango máximo de consulta es de 1 mes, gracias por entender.";
                    sinresultado.Visible = true;
                    return;
                }
                var user = Page.getUserBySesion();
                ta.ClearBeforeFill = true;
                //user.loginname = "botrosa";
                ta.Fill(table, user.loginname, this.aisvn.Text.Trim(), this.docnum.Text.Trim(), this.cntrn.Text.Trim(), this.booking.Text.Trim(), desde, hasta);
                if (table.Rows.Count <= 0)
                {
                    xfinder.Visible = false;
                    sinresultado.Attributes["class"] = string.Empty;
                    sinresultado.Attributes["class"] = "msg-info";
                    this.sinresultado.InnerText = "No se encontraron resultados, revise la unidad, documento o # aisv";
                    sinresultado.Visible = true;
                    return;
                }

                Session["resultado"] = table;
                this.tablePagination.DataSource = table;
                this.tablePagination.DataBind();
                xfinder.Visible = true;
            }
            catch (Exception ex)
            {
                var t = this.getUserBySesion();
                sinresultado.Attributes["class"] = string.Empty;
                sinresultado.Attributes["class"] = "msg-critico";
                sinresultado.InnerText = string.Format("Ha ocurrido un problema durante la carga de datos, por favor repórtelo con este código E00-{0}, gracias por entender.", csl_log.log_csl.save_log<Exception>(ex, "consulta", "populate", "Hubo un error al buscar", t.loginname));
                sinresultado.Visible = true;
            }
            finally
            {
                ta.Dispose();
                table.Dispose();
            }
        }


        [WebMethod]
        public static string ConsultarFechaHoraAISV(string aisv)
        {
            try
            {
                VBS_CabeceraPlantilla objCab = new VBS_CabeceraPlantilla();
                jAisvContainer dbo = new jAisvContainer();
                var user = new usuario();

                user = usuario.Deserialize(HttpContext.Current.Session["control"].ToString());

                var json = dbo.GetFechaYHoraAISV(aisv);

                // Convertir el objeto json a una cadena JSON
                string jsonStr = JsonConvert.SerializeObject(json);

                // Devolver la cadena JSON como respuesta
                return jsonStr;
            }
            catch (Exception ex)
            {
                throw new Exception("error", ex);
            }
        }




        [WebMethod]
        public static string ConsultarEventosPorDiaAISV(string start, string varTodos, string aisv)
        {
            try
            {
                List<EventoCalendario> eventos = new List<EventoCalendario>();

                DateTime fechaSeleccionada = DateTime.ParseExact(start, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                DateTime fechaActual = DateTime.Now;

                string fechaRestadaString = fechaSeleccionada.ToString("yyyy-MM-dd");

                // Verificar si la fecha seleccionada es la fecha actual
                bool esFechaActual = fechaSeleccionada.Date == fechaActual.Date;

                VBS_CabeceraPlantilla objCab = new VBS_CabeceraPlantilla();
                jAisvContainer dbo = new jAisvContainer();

                var getTipoCarga = string.Empty;
                var CodigoContenedorAisvRegistro = string.Empty;
                CodigoContenedorAisvRegistro = dbo.GetCodigoIso(aisv);
                getTipoCarga = dbo.GetISO(CodigoContenedorAisvRegistro);
                if (varTodos == "TODOS")
                {
                    getTipoCarga = "ALL";
                    var consultaTurnosDetalle = objCab.GetListaTurnosPorDiaTipoContenedorALL(fechaRestadaString, getTipoCarga,100);

                    if (consultaTurnosDetalle.Resultado != null)
                    {
                        foreach (VBS_TurnosDetalle detalle in consultaTurnosDetalle.Resultado)
                        {
                            EventoCalendario evento = new EventoCalendario();
                            evento.title = $"{detalle.TipoCargas} - {detalle.TipoContenedor}"; // Combinar tipo_contenedor y total_turnos
                            evento.start = fechaRestadaString;
                            evento.end = fechaRestadaString;
                            if (detalle.TipoCargaId == 1)
                                evento.color = "#336BFF";
                            if (detalle.TipoCargaId == 2)
                                evento.color = "#17a2b8";
                            if (detalle.TipoCargaId == 3)
                                evento.color = "#dc3545";

                            evento.horario = detalle.Horario.ToString(@"hh\:mm");
                            evento.idDetalle = detalle.IdTurno;
                            evento.cantidad = detalle.Disponible;
                            // Si es la fecha actual, verificar si la hora ya ha pasado o no tiene suficiente anticipación
                            if (esFechaActual)
                            {
                                DateTime horaEvento = fechaSeleccionada.Date + detalle.Horario;
                                TimeSpan anticipacionMinima = new TimeSpan(0, 45, 0);
                                DateTime horaLimite = fechaActual.Add(anticipacionMinima);

                                if (horaEvento < horaLimite)
                                {
                                    // La hora ya ha pasado o no tiene suficiente anticipación, no se agrega al evento
                                    continue;
                                }
                            }

                            eventos.Add(evento);
                        }
                    }

                    JavaScriptSerializer serializer = new JavaScriptSerializer();
                    string json = serializer.Serialize(eventos.ToArray());

                    // Serializar los datos de eventos paginados a JSON
                    return json;
                }
                else
                {

                    var consultaTurnosDetalle = objCab.GetListaTurnosPorDiaTipoContenedor(fechaRestadaString, getTipoCarga,100);

                    if (consultaTurnosDetalle.Resultado != null)
                    {
                        foreach (VBS_TurnosDetalle detalle in consultaTurnosDetalle.Resultado)
                        {
                            EventoCalendario evento = new EventoCalendario();
                            evento.title = $"{detalle.TipoCargas} - {detalle.TipoContenedor}"; // Combinar tipo_contenedor y total_turnos
                            evento.start = fechaRestadaString;
                            evento.end = fechaRestadaString;
                            if (detalle.TipoCargaId == 1)
                                evento.color = "#336BFF";
                            if (detalle.TipoCargaId == 2)
                                evento.color = "#17a2b8";
                            if (detalle.TipoCargaId == 3)
                                evento.color = "#dc3545";

                            evento.horario = detalle.Horario.ToString(@"hh\:mm");
                            evento.idDetalle = detalle.IdTurno;
                            evento.cantidad = detalle.Disponible;
                            // Si es la fecha actual, verificar si la hora ya ha pasado o no tiene suficiente anticipación
                            if (esFechaActual)
                            {
                                DateTime horaEvento = fechaSeleccionada.Date + detalle.Horario;
                                TimeSpan anticipacionMinima = new TimeSpan(0, 45, 0);
                                DateTime horaLimite = fechaActual.Add(anticipacionMinima);

                                if (horaEvento < horaLimite)
                                {
                                    // La hora ya ha pasado o no tiene suficiente anticipación, no se agrega al evento
                                    continue;
                                }
                            }

                            eventos.Add(evento);
                        }
                    }

                    JavaScriptSerializer serializer = new JavaScriptSerializer();
                    string json = serializer.Serialize(eventos.ToArray());

                    // Serializar los datos de eventos paginados a JSON
                    return json;
                }


            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar eventos en el servidor", ex);
            }
        }


        [WebMethod]

        public static string ActualizarTurnoPorAISV(string idTurno, string fecha, string horallegada, string aisv)
        {
            try
            {
                VBS_CabeceraPlantilla objCab = new VBS_CabeceraPlantilla();
                jAisvContainer dbo = new jAisvContainer();
                var user = new usuario();

                CultureInfo enUS = new CultureInfo("en-US");
                DateTime fechaConvertida;//= fecha; // Asumiendo que es "12/9/2023" en formato local

                if (!DateTime.TryParseExact(fecha, "dd/MM/yyyy", enUS, DateTimeStyles.None, out fechaConvertida))
                {
                    return null;
                }

                user = usuario.Deserialize(HttpContext.Current.Session["control"].ToString());

                DateTime fechaActual = DateTime.Now;
               
                TimeSpan horallegadaTime = TimeSpan.Parse(horallegada);
                
                var idTurnoAnterior = dbo.GetIdturno(aisv);
                objCab.EditarTurnoCanceladoAISV(aisv, idTurnoAnterior, user.loginname, fechaActual);

                dbo.UpdateAisvRegistro(idTurno, fechaConvertida, horallegadaTime, aisv);
                objCab.EditarTurnoDisponibles(Convert.ToInt32(idTurno), user.loginname, fechaActual, aisv, "", "", "");



                return null;
            }
            catch (Exception ex)
            {
                throw new Exception("error", ex);
            }


        }

    }
}