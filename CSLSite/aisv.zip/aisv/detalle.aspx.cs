﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using csl_log;

namespace CSLSite
{
    public partial class detalleaisv : System.Web.UI.Page
    {
        private string sid = string.Empty;
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            ViewStateUserKey = Session.SessionID;

        }

        protected void Page_Init(object sender, EventArgs e)
        {

            if (!HttpContext.Current.Request.IsAuthenticated)
            {
                csl_log.log_csl.save_log<ApplicationException>(new ApplicationException("No autenticado"), "detalleaisv", "Page_Init", "No autenticado", "No disponible");
                this.PersonalResponse("Para acceder a esta área necesita estar autenticado, será redireccionado a la página de login","../login.aspx",true);
            }
            try
            {
                sid = QuerySegura.DecryptQueryString(Request.QueryString["sid"]);
                if (Request.QueryString["sid"] == null || string.IsNullOrEmpty(sid))
                {
                    var ex = new ApplicationException(string.Format("IP:{0},URL:{1},METODO:{2}, Tabla de impresiones vacía", Request.UserHostAddress, Request.Url, Request.HttpMethod));
                    var number = log_csl.save_log<Exception>(ex, "QuerySegura", "DecryptQueryString", sid, Request.UserHostAddress);
                    this.PersonalResponse("Está intentando acceder a un área restringida, por su seguridad los datos de su equipo han quedado registrados, gracias.", "../login.aspx", true);
                    return;
                }
            }
            catch (Exception ex)
            {
                var number = log_csl.save_log<Exception>(ex, "detalleaisv", "Page_Init", sid, Request.UserHostAddress);
                this.PersonalResponse(string.Format("Lo sentimos, algo salió mal. Estamos trabajando para solucionarlo lo más pronto posible, por favor reporte este código de servicio: A00-{0}",number), null);
                return;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Response.IsClientConnected)
            {
                try
                {
                    sid = sid.Trim().Replace("\0", string.Empty);
                    this.aisv.InnerText = string.Format("Numero de AISV:{0}",sid);

                    var tb = jAisvContainer.getMyDetails(sid);
                    if (tb == null || tb.Count<=0)
                    {
                        var ex = new ApplicationException(string.Format("No se encontraron detalles del aisv:{0}",sid));
                        var number = log_csl.save_log<Exception>(ex, "detalleaisv", "Page_Load", sid, Request.UserHostAddress);
                        this.PersonalResponse(string.Format("Lo sentimos, algo salió mal. Estamos trabajando para solucionarlo lo más pronto posible, por favor reporte este código de servicio: A00-{0}", number), null);
                        return;
                    }
                    this.tablePagination.DataSource = tb;
                    this.tablePagination.DataBind();
                }
                catch (Exception ex)
                {
                    var number = log_csl.save_log<Exception>(ex, "detalleaisv", "Page_Init", sid, Request.UserHostAddress);
                    this.PersonalResponse(string.Format("Lo sentimos, algo salió mal. Estamos trabajando para solucionarlo lo más pronto posible, por favor reporte este código de servicio: A00-{0}", number), null);
                    return;
                }
                finally
                {
                    
                }
            }
        }

      
    }
}