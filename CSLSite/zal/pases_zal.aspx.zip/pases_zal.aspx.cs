﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using CSLSite.N4Object;
using ConectorN4;
using System.Globalization;
using System.Web.Script.Services;
using System.Configuration;
using Newtonsoft.Json;
using csl_log;
using System.Xml;
using System.Xml.Linq;
using System.Data;
using System.IO;
using System.Data.SqlClient;
using System.Collections;

namespace CSLSite.zal
{
    public partial class pases_zal : System.Web.UI.Page
    {
        private DataTable p_drPlaca
        {
            get
            {
                return (DataTable)Session["drPlacaPPWeb"];
            }
            set
            {
                Session["drPlacaPPWeb"] = value;
            }

        }

        private DataTable p_drChoferFilter
        {
            get
            {
                return (DataTable)Session["drChoferFilterPPWeb"];
            }
            set
            {
                Session["drChoferFilterPPWeb"] = value;
            }

        }

        private DataTable p_drChofer
        {
            get
            {
                return (DataTable)Session["drChoferPPWeb"];
            }
            set
            {
                Session["drChoferPPWeb"] = value;
            }

        }

        public DataTable dtTurnosZAL
        {
            get { return (DataTable)Session["dtTurnosZAL"]; }
            set { Session["dtTurnosZAL"] = value; }
        }

        public DataTable dtDetpasezal
        {
            get { return (DataTable)Session["dtDetpasezal"]; }
            set { Session["dtDetpasezal"] = value; }
        }

        public DataTable dtListaAsumeCliente
        {
            get { return (DataTable)Session["dtListaAsumeCliente"]; }
            set { Session["dtListaAsumeCliente"] = value; }
        }

        public DataTable dtListaBooking
        {
            get { return (DataTable)Session["dtListaBooking"]; }
            set { Session["dtListaBooking"] = value; }
        }

        public String emailCliente
        {
            get { return (String)Session["emailCliente"]; }
            set { Session["emailCliente"] = value; }
        }

        public Boolean ClienteBloqueado
        {
            get { return (Boolean)Session["ValClienteBloqueado"]; }
            set { Session["ValClienteBloqueado"] = value; }
        }

        public Boolean ClienteTipo
        {
            get { return (Boolean)Session["ValClienteTipo"]; }
            set { Session["ValClienteTipo"] = value; }
        }

        private static int cont=0;
        private static int pos=0;
        WFCPASEPUERTA.WFCPASEPUERTAClient WPASEPUERTA;
        //SI_Customer_Statement_NAVIS_CGSA.Ws_Sap_EstadoDeCuenta WsSapEstadoDeCuenta = new SI_Customer_Statement_NAVIS_CGSA.Ws_Sap_EstadoDeCuenta();
        //AntiXRCFG.
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            ViewStateUserKey = Session.SessionID;
        }

        protected void Page_Init(object sender, EventArgs e)
        {

          

            if (!Request.IsAuthenticated)
            {
                csl_log.log_csl.save_log<ApplicationException>(new ApplicationException("No autenticado"), "container", "Page_Init", "No autenticado", "No disponible");
                this.PersonalResponse("Para acceder a esta área necesita estar autenticado, será redireccionado a la página de login", "../csl/login", true);
            }
            this.IsAllowAccess();
            var user = Page.Tracker();

            if (user != null && !string.IsNullOrEmpty(user.nombregrupo))
            {
                var t = CslHelper.getShiperName(user.ruc);
                if (string.IsNullOrEmpty(user.ruc))
                {
                    csl_log.log_csl.save_log<ApplicationException>(new ApplicationException("Usuario sin línea"), "turnos", "Page_Init", user.ruc, user.loginname);
                    this.PersonalResponse("Su cuenta de usuario no tiene asociada una línea, arregle esto primero con Customer Services", "../csl/login", true);
                }
                this.agencia.Value = user.ruc;
                this.emailCliente = user.email;
                this.ClienteBloqueado = user.bloqueo_cartera; // si es true esta bloqueado si es false no esta bloqueado
                this.ClienteTipo = user.IsCredito;
            }
            if (!IsPostBack)
            {
                this.IsCompatibleBrowser();
                Page.SslOn();
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
                {
                    /*
                    dtListaAsumeCliente = new DataTable();
                    dtListaAsumeCliente.Columns.Add("REFERENCIA");
                    dtListaAsumeCliente.Columns.Add("NAVE");
                    dtListaAsumeCliente.Columns.Add("BOOKING");
                    dtListaAsumeCliente.Columns.Add("CODIGOSAP");
                    dtListaAsumeCliente.Columns.Add("RUC");
                    dtListaAsumeCliente.Columns.Add("RAZSOCIAL");
                    dtListaAsumeCliente.Columns.Add("EMAIL");
                    dtListaAsumeCliente.Columns.Add("TIPO");
                    */
                    //gv.DataSource = odsTurnosList;
                    //gv.DataBind();

                    dtListaBooking = new DataTable();
                    dtListaBooking.Columns.Add("BOOKING");
                    dtListaBooking.Columns.Add("REFERENCIA");
                    dtListaBooking.Columns.Add("LINEA");
                    dtListaBooking.Columns.Add("MENSAJE");
                    RepeaterBooking.DataSource = dtListaBooking;
                    RepeaterBooking.DataBind();
                    fecsalida.Text = DateTime.Now.ToString("dd/MM/yyyy");
                    IniDsChofer("");
                    IniDsPlaca("");
                    //var r = man_pro_expo.GetCatalagoReferenciasPagoTerceros();

                }
                catch (Exception ex)
                {
                    var number = log_csl.save_log<Exception>(ex, "pago_terceros", "Page_Load()", DateTime.Now.ToShortDateString(), Page.User.Identity.Name);
                    this.Alerta(string.Format("Lo sentimos, algo salió mal. Estamos trabajando para solucionarlo lo más pronto posible, por favor reporte este código de servicio: A00-{0}", number.ToString()));
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getGifOculta();", true);
                }
            }
        }

        private void IniDsPlaca(string empresa)
        {
            p_drPlaca = pasePuerta.GetPlacainfozal(empresa);
        }

        private void IniDsChofer(string empresa)
        {
            DataSet dsRetorno = new DataSet();
            WPASEPUERTA = new WFCPASEPUERTA.WFCPASEPUERTAClient();
            var dtRetorno = pasePuerta.GetChoferinfozal(empresa);
            if (dtRetorno.Rows.Count > 0)
            {
                DataView myDataView = dtRetorno.DefaultView;
                myDataView.Sort = "CHOFER ASC";

                p_drChofer = myDataView.ToTable();
                p_drChoferFilter = p_drChofer;
            }
        }

        protected void fecsalida_TextChanged(object sender, EventArgs e)
        {
            try
            {
                CultureInfo enUS = new CultureInfo("en-US");
                DateTime fechasal = new DateTime();
                if (!DateTime.TryParseExact(fecsalida.Text, "dd/MM/yyyy", enUS, DateTimeStyles.None, out fechasal))
                {
                    this.Alerta(string.Format("<strong>&nbsp;EL FORMATO DE FECHA DEBE SER dia/Mes/Anio {0}</strong>", fecsalida.Text));
                    fecsalida.Focus();
                    return;
                }
                dtTurnosZAL = new DataTable();
                dtTurnosZAL = N4_P_Cons_Turnos_Disponibles_ZAL(fechasal.ToString("yyyy-MM-dd"));
                dtTurnosZAL.Columns.Add("CHECK");
                

            }
            catch (Exception ex)
            {
                var number = log_csl.save_log<Exception>(ex, "pago_terceros", "Page_Load()", DateTime.Now.ToShortDateString(), Page.User.Identity.Name);
                this.Alerta(string.Format("Lo sentimos, algo salió mal. Estamos trabajando para solucionarlo lo más pronto posible, por favor reporte este código de servicio: A00-{0}", number.ToString()));
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getGifOculta();", true);
            }
        }

        private static SqlConnection ConexionN4Middleware()
        {
            return new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["midle"].ConnectionString);
        }

        public static DataTable N4_P_Cons_Turnos_Disponibles_ZAL(string fecha)
        {
            var d = new DataTable();
            using (var c = ConexionN4Middleware())
            {
                var coman = c.CreateCommand();
                coman.CommandType = CommandType.StoredProcedure;
                coman.CommandText = "N4_P_Cons_Turnos_Disponibles_ZAL";
                coman.Parameters.AddWithValue("@FECHA", fecha);
                try
                {
                    c.Open();
                    d.Load(coman.ExecuteReader(CommandBehavior.CloseConnection));
                }
                catch (SqlException ex)
                {
                    csl_log.log_csl.save_log<SqlException>(ex, "pasePuerta", "GetInfoEmails", "SP_GET_INFO_EMAILS_PPWEB", DateTime.Now.ToShortDateString());
                }
                finally
                {
                    if (c.State == ConnectionState.Open)
                    {
                        c.Close();
                    }
                    c.Dispose();
                }
            }
            return d;
        }

        protected void btsalvar_Click(object sender, EventArgs e)
        {
            try
            {

                if (dtListaBooking.Rows.Count == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getGifOcultaEnviar('¡ " + "Aun no Agrega Bookings a la lista." + "');getGifOcultaBuscar();", true);
                    return;
                }

                string mail = string.Empty;
                string error = string.Empty;
                string correoBackUp = string.Empty;
                string mail_em = string.Empty;
                string sUser_email = string.Empty;
                string destinatarios = string.Empty;
                string mensajeerror = string.Empty;

                string mailContenedores = string.Empty;
                int cont = 0;
                int add = 0;
                string mensaje = null;
                string mensajeu = null;

                for (int i = 0; i < dtListaBooking.Rows.Count; i++)
                {
                    if (!man_pro_expo.AddBookAutoriza(
                        dtListaBooking.Rows[i]["BOOKING"].ToString(),
                        dtListaBooking.Rows[i]["REFERENCIA"].ToString(),
                        dtListaBooking.Rows[i]["LINEA"].ToString(),
                        Page.User.Identity.Name.ToUpper(),
                        out mensaje))
                    {
                        //ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getGifOcultaEnviar('¡ " + mensaje + "');", true);
                        cont += 1;
                        mensajeu = mensaje;
                        if (mensaje.Contains("ya se encuentra autorizado"))
                            dtListaBooking.Rows[i]["MENSAJE"] = "Registro duplicado";
                        else
                            dtListaBooking.Rows[i]["MENSAJE"] = mensaje.Length > 30 ? mensaje.Substring(1, 30) : mensaje;
                    }
                    else
                    {


                        //if (!string.IsNullOrEmpty(error))
                        //{
                        //    //ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", error, true);
                        //    return;
                        //}
                        add += 1;
                        dtListaBooking.Rows[i]["MENSAJE"] = "Registrado con éxito";
                    }
                }

                RepeaterBooking.DataSource = dtListaBooking;
                RepeaterBooking.DataBind();

                if (cont == 0)
                    Response.Write("<script language='JavaScript'>var r=alert('Transacción exitosa todos los bookings fueron registrados.');if(r==true){window.location='../csl/menu';}else{window.location='../csl/menu';}</script>");
                else
                {
                    this.Alerta(string.Format("Algunos registros reportaron error verifique los mensajes: bookings registrados {0}, bookings con error {1}.", add,cont));
                    //ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getGifOcultaEnviar('¡ " + mensajeu + "');", true);
                }
            }
            catch (Exception ex)
            {
                var number = log_csl.save_log<Exception>(ex, "booking_atoriza", "btsalvar_Click()", DateTime.Now.ToShortDateString(), Page.User.Identity.Name);
                this.Alerta(string.Format("Lo sentimos, algo salió mal. Estamos trabajando para solucionarlo lo más pronto posible, por favor reporte este código de servicio: A00-{0}", number.ToString()));
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getGifOcultaEnviar('¡ " + ex.Message + "');", true);
            }
        }

        protected void RepeaterBooking_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            try
            {
                if (e.CommandName.Contains("Delete")) //breakpoint on this line
                {
                    String value = dtDetpasezal.Rows[e.Item.ItemIndex]["IDPZAL"].ToString();
                    string mensaje = null;
                    if (!man_pro_expo.AddCancelPaseZAL(
                        value,
                        Page.User.Identity.Name,
                        out mensaje))
                    {
                        this.Alerta(mensaje);
                        return;
                    }
                    else
                    {
                        this.Alerta("Pase: " +  value + ", cancelado exitosamente.");
                        //dtDetpasezal.Rows.RemoveAt(e.Item.ItemIndex);
                        //dtDetpasezal.AcceptChanges();
                        CultureInfo enUS = new CultureInfo("en-US");
                        DateTime fechasal = new DateTime();
                        if (!DateTime.TryParseExact(fecsalida.Text, "dd/MM/yyyy", enUS, DateTimeStyles.None, out fechasal))
                        {
                            this.Alerta(string.Format("<strong>&nbsp;EL FORMATO DE FECHA DEBE SER dia/Mes/Anio {0}</strong>", fecsalida.Text));
                            fecsalida.Focus();
                            return;
                        }
                        var detpasezal = man_pro_expo.GetDetallePaseZAL(nbrboo.Value, xreferencia.Value, fechasal.ToString("yyyy-MM-dd"), xlinea.Value);
                        if (detpasezal.Rows.Count == 0 || detpasezal == null)
                        {
                            RepeaterBooking.DataSource = null;
                            RepeaterBooking.DataBind();
                            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getBookOculta();", true);
                            return;
                        }
                        dtDetpasezal = new DataTable();
                        //dtListaBooking.Rows.Add(nbrboo.Value, xreferencia.Value, xlinea.Value);
                        dtDetpasezal = detpasezal;
                        RepeaterBooking.DataSource = detpasezal;
                        RepeaterBooking.DataBind();
                        //lblTotPases.Text = "Tot. Pases: " + detpasezal.Rows.Count.ToString();
                        //RepeaterBooking.DataSource = dtListaBooking;
                        //RepeaterBooking.DataBind();
                    }
                    //ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getBookOculta();", true);
                }
                else if (e.CommandName == "Imprimir") //breakpoint on this line
                {
                    StringWriter xmlPPWeb = new StringWriter();
                    Int64 value = Convert.ToInt64(dtDetpasezal.Rows[e.Item.ItemIndex]["IDPZAL"].ToString());
                    var query = from myRow in dtDetpasezal.AsEnumerable()
                                where myRow.Field<Int64>("IDPZAL") == value
                                select myRow;
                    DataTable tbresult = new DataTable();
                    tbresult = query.AsDataView().ToTable();
                    tbresult.TableName = "PaseWeb";
                    tbresult.WriteXml(xmlPPWeb);

                    Session["idpaseszal"] = xmlPPWeb.ToString();
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "openPopReporte();", true);
                }
                else if (e.CommandName == "Update")
                {
                    //Object DataItem = (Object)e.Item.FindControl;
                    //CheckBox chkPase = (CheckBox)sender;
                    //RepeaterItem item = (RepeaterItem)DataItem.NamingContainer;
                    TextBox txtchofer = (Object)e.Item.FindControl("txtchofer") as TextBox;
                    TextBox txtplaca = (Object)e.Item.FindControl("txtplaca") as TextBox;
                    Label lblFechaSalida = (Object)e.Item.FindControl("lblFechaSalida") as Label;
                    Label lblTurno = (Object)e.Item.FindControl("lblTurno") as Label;
                    
                    DataTable DTRESULT2 = new DataTable();
                    DTRESULT2 = (DataTable)HttpContext.Current.Session["drChoferFilterPPWeb"];
                    if (DTRESULT2 != null)
                    {
                        if (DTRESULT2.Rows.Count > 0)
                        {
                            var valcho = (from currentStat in DTRESULT2.Select("CHOFER = '" + txtchofer.Text.Trim() + "'").AsEnumerable()
                                          select currentStat.Field<String>("CHOFER")).ToList().Take(5);
                            string[] aChof = valcho.ToArray<string>();
                            if (aChof.Count() > 0)
                            {
                                txtchofer.Text = aChof[0].ToString();
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(txtchofer.Text))
                                {
                                    this.Alerta("El Chofer: " + txtchofer.Text + " no es valido.");
                                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "ocultagiffecha();", true);
                                    txtchofer.Focus();
                                    return;
                                }
                            }
                        }
                    }

                    var wPlaca = (from row in p_drPlaca.AsEnumerable()
                                  where row.Field<String>("PLACA") != null && row.Field<String>("PLACA").Trim().Equals(txtplaca.Text.ToString().Trim().ToUpper())
                                  select row.Field<String>("PLACA")).Count();

                    if ((int)wPlaca <= 0)
                    {
                        this.Alerta("La Placa: " + txtplaca.Text + ", no es valida.");
                        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "ocultagiffecha();", true);
                        txtplaca.Focus();
                        return;
                    }
                    CultureInfo enUS = new CultureInfo("en-US");
                    DateTime fechasal = new DateTime();
                    if (!DateTime.TryParseExact(lblFechaSalida.Text, "dd/MM/yyyy", enUS, DateTimeStyles.None, out fechasal))
                    {
                        //this.Alerta(string.Format("<strong>&nbsp;EL FORMATO DE FECHA DEBE SER dia/Mes/Anio {0}</strong>", lblFechaSalida.Text));
                        //return;
                    }
                    var v_turno = pasePuerta.GetValTurno(fechasal.ToString("yyyy-MM-dd"), lblTurno.Text.Substring(3,6).Trim());
                    if (v_turno.Rows[0]["V_TURNO"].ToString() == "1")
                    {
                        var v_msg = v_turno.Rows[0]["MENSAJE"].ToString().Substring(0, 130);
                        this.Alerta(v_msg);
                        return;
                    }

                    String value = dtDetpasezal.Rows[e.Item.ItemIndex]["IDPZAL"].ToString();
                    string mensaje = null;
                    if (!man_pro_expo.AddUpdatePaseZAL(
                        value,
                        Page.User.Identity.Name,
                        txtchofer.Text.ToUpper().Trim(),
                        txtplaca.Text.ToUpper().Trim(),
                        out mensaje))
                    {
                        this.Alerta(mensaje);
                        return;
                    }
                    else
                    {
                        this.Alerta("Pase: " + value + ", actualizado exitosamente.");
                        //CultureInfo enUS = new CultureInfo("en-US");
                        /*DateTime fechasal_ = new DateTime();
                        if (!DateTime.TryParseExact(fecsalida.Text, "dd/MM/yyyy", enUS, DateTimeStyles.None, out fechasal_))
                        {
                        }
                        */
                        var detpasezal = man_pro_expo.GetDetallePaseZAL(nbrboo.Value, xreferencia.Value, fechasal.ToString("yyyy-MM-dd"), xlinea.Value);
                        if (detpasezal.Rows.Count == 0 || detpasezal == null)
                        {
                            RepeaterBooking.DataSource = null;
                            RepeaterBooking.DataBind();
                            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getBookOculta();", true);
                            return;
                        }
                        dtDetpasezal = new DataTable();
                        //dtListaBooking.Rows.Add(nbrboo.Value, xreferencia.Value, xlinea.Value);
                        dtDetpasezal = detpasezal;
                        RepeaterBooking.DataSource = detpasezal;
                        RepeaterBooking.DataBind();

                        StringWriter xmlPPWeb = new StringWriter();
                        Int64 value_ = Convert.ToInt64(dtDetpasezal.Rows[e.Item.ItemIndex]["IDPZAL"].ToString());
                        var query = from myRow in dtDetpasezal.AsEnumerable()
                                    where myRow.Field<Int64>("IDPZAL") == value_
                                    select myRow;
                        DataTable tbresult = new DataTable();
                        tbresult = query.AsDataView().ToTable();
                        tbresult.TableName = "PaseWeb";
                        tbresult.WriteXml(xmlPPWeb);

                        Session["idpaseszal"] = xmlPPWeb.ToString();
                        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "openPopReporte();", true);
                        //lblTotPases.Text = "Tot. Pases: " + detpasezal.Rows.Count.ToString();
                        //RepeaterBooking.DataSource = dtListaBooking;
                        //RepeaterBooking.DataBind();
                    }
                }
            }
            catch (Exception ex)
            {
                var number = log_csl.save_log<Exception>(ex, "autoriza_booking", "RepeaterBooking_ItemCommand()", DateTime.Now.ToShortDateString(), Page.User.Identity.Name);
                this.Alerta(string.Format("Lo sentimos, algo salió mal. Estamos trabajando para solucionarlo lo más pronto posible, por favor reporte este código de servicio: A00-{0}", number.ToString()));
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getGifOculta();", true);
            }
        }

        protected void btnAsumirBook_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(nbrboo.Value))
                {
                    this.Alerta("Fata el Booking.");
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getBookOculta();", true);
                    return;
                }
                if (string.IsNullOrEmpty(xreferencia.Value))
                {
                    this.Alerta("Falta la Referencia.");
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getBookOculta();", true);
                    return;
                }
                if (string.IsNullOrEmpty(xlinea.Value))
                {
                    this.Alerta("Falta la Linea.");
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getBookOculta();", true);
                    return;
                }
                if (string.IsNullOrEmpty(fecsalida.Text))
                {
                    this.Alerta("Falta la Fecha de Salida.");
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getBookOculta();", true);
                    return;
                }
                CultureInfo enUS = new CultureInfo("en-US");
                DateTime fechasal = new DateTime();
                if (!DateTime.TryParseExact(fecsalida.Text, "dd/MM/yyyy", enUS, DateTimeStyles.None, out fechasal))
                {
                    this.Alerta(string.Format("EL FORMATO DE FECHA DEBE SER dia/Mes/Anio, {0}", fecsalida.Text));
                    fecsalida.Focus();
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getBookOculta();", true);
                    return;
                }

                var query = from myRow in dtListaBooking.AsEnumerable()
                            where myRow.Field<string>("REFERENCIA") == xreferencia.Value.ToString() && myRow.Field<string>("BOOKING") == nbrboo.Value.ToString()
                            select myRow;
                DataTable tbresult = query.AsDataView().ToTable();

                if (tbresult.Rows.Count == 0)
                {
                    var detpasezal = man_pro_expo.GetDetallePaseZAL(nbrboo.Value, xreferencia.Value, fechasal.ToString("yyyy-MM-dd"), xlinea.Value);
                    if (detpasezal.Rows.Count == 0 || detpasezal == null)
                    {
                        this.Alerta("No se encontraron datos, revise los criterios de consulta.");
                        RepeaterBooking.DataSource = null;
                        RepeaterBooking.DataBind();
                        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getBookOculta();", true);
                        return;
                    }
                    dtDetpasezal = new DataTable();
                    //dtListaBooking.Rows.Add(nbrboo.Value, xreferencia.Value, xlinea.Value);
                    dtDetpasezal = detpasezal;
                    RepeaterBooking.DataSource = detpasezal;
                    RepeaterBooking.DataBind();
                    //lblTotPases.Text = "Tot. Pases: "; + detpasezal.Rows.Count.ToString();
                    //ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getGifOcultaBuscar();", true);
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getBookOculta();", true);
                }
            }
            catch (Exception ex)
            {
                var number = log_csl.save_log<Exception>(ex, "autoriza_booking", "btnAsumirBook_Click()", DateTime.Now.ToShortDateString(), Page.User.Identity.Name);
                this.Alerta(string.Format("Lo sentimos, algo salió mal. Estamos trabajando para solucionarlo lo más pronto posible, por favor reporte este código de servicio: A00-{0}", number.ToString()));
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getBookOculta();", true);
            }
        }

        protected void btnCancelaPase(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                var number = log_csl.save_log<Exception>(ex, "autoriza_booking", "btnCancelaPase()", DateTime.Now.ToShortDateString(), Page.User.Identity.Name);
                this.Alerta(string.Format("Lo sentimos, algo salió mal. Estamos trabajando para solucionarlo lo más pronto posible, por favor reporte este código de servicio: A00-{0}", number.ToString()));
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getGifOculta();", true);
            }
        }

        protected void btnReImprimirPase(object sender, EventArgs e)
        {
            try
            {
                
            }
            catch (Exception ex)
            {
                var number = log_csl.save_log<Exception>(ex, "autoriza_booking", "btnReImprimirPase()", DateTime.Now.ToShortDateString(), Page.User.Identity.Name);
                this.Alerta(string.Format("Lo sentimos, algo salió mal. Estamos trabajando para solucionarlo lo más pronto posible, por favor reporte este código de servicio: A00-{0}", number.ToString()));
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "getGifOculta();", true);
            }
        }

        [System.Web.Services.WebMethod]
        public static string[] GetChoferList(string prefix)
        {

            WFCPASEPUERTA.WFCPASEPUERTAClient WPASEPUERTA = new WFCPASEPUERTA.WFCPASEPUERTAClient();

            DataSet dsRetorno = new DataSet();
            WPASEPUERTA = new WFCPASEPUERTA.WFCPASEPUERTAClient();

            DataTable DTRESULT = new DataTable();
            DTRESULT = (DataTable)HttpContext.Current.Session["drChoferFilterPPWeb"];//drChoferPPWeb"];

            if (DTRESULT != null)
            {
                var list = /*(from currentStat in DTRESULT.AsEnumerable()
                        where currentStat.Field<String>("CHOFER") != null && currentStat.Field<String>("CHOFER").Contains(prefixText.ToUpper())
                        select currentStat.Field<String>("IDCHOFER") + " - " + currentStat.Field<String>("CHOFER")).ToList().Take(5);*/

                (from currentStat in DTRESULT.Select("CHOFER like '%" + prefix + "%'").AsEnumerable()
                 select currentStat.Field<String>("CHOFER")).ToList().Take(5);

                string[] prefixTextArray = list.ToArray<string>();
                return prefixTextArray;
            }
            else
            {
                ArrayList myAL = new ArrayList();
                // Add stuff to the ArrayList.
                string[] myArr = (String[])myAL.ToArray(typeof(string));
                string[] prefixTextArray2 = myArr.ToArray<string>();
                return prefixTextArray2;
            }
            //Return Selected Products
        }
    }
}