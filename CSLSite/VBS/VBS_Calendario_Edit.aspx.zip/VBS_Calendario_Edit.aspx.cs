﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Globalization;
using BillionEntidades;
using N4;
using N4Ws;
using N4Ws.Entidad;
using System.Xml.Linq;
using System.Xml;
using ControlPagos.Importacion;
using Salesforces;
using System.Data;
using System.Net;
using SqlConexion;
using CasManual;

using System.Reflection;
using System.ComponentModel;
using VBSEntidades.Plantilla;
using VBSEntidades;
using VBSEntidades.ClaseEntidades;
using System.Web.Services;
using VBSEntidades.Calendario;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using Newtonsoft.Json;
using ProcesaUnits;

namespace CSLSite
{


    public partial class VBS_Calendario_Edit : System.Web.UI.Page
    {

        #region "Clases"

        private Cls_Bil_Sesion objSesion = new Cls_Bil_Sesion();
        usuario ClsUsuario;

        private string cMensajes;
        VBS_CabeceraPlantilla objPlantilla = new VBS_CabeceraPlantilla();
        VBS_TurnosDetalle _objTurnos = new VBS_TurnosDetalle();
        List<VBS_TurnosDetalle> ListTurnos = new List<VBS_TurnosDetalle>();


        #endregion

        #region "Variables"

        private string LoginName = string.Empty;


        /*variables control de credito*/

        private Cls_Bil_PasePuertaCFS_Cabecera objCas = new Cls_Bil_PasePuertaCFS_Cabecera();
        private Cls_Bil_CasManual objDetalleCas = new Cls_Bil_CasManual();

        private VBS_CabeceraPlantilla objCab = new VBS_CabeceraPlantilla();
        private VBS_DetallePlantilla objDet = new VBS_DetallePlantilla();
        #endregion

        #region "Propiedades"

        private Int64? nSesion
        {
            get
            {
                return (Int64)Session["nSesion"];
            }
            set
            {
                Session["nSesion"] = value;
            }

        }




        #endregion

        #region "Metodos"




        private void OcultarLoading(string valor)
        {
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popup", "ocultarloader('" + valor + "');", true);
        }

        public static string securetext(object number)
        {
            if (number == null)
            {
                return string.Empty;
            }
            return QuerySegura.EncryptQueryString(number.ToString());
        }

        private void Mostrar_Mensaje(int Tipo, string Mensaje)
        {
            if (Tipo == 1)//cabecera
            {
                //      this.banmsg.Visible = true;
                //         this.banmsg.InnerHtml = Mensaje;
                OcultarLoading("1");
            }


        }

        private void Ocultar_Mensaje()
        {
             
            OcultarLoading("1");

        }


        private void Crear_Sesion()
        {
            objSesion.USUARIO_CREA = ClsUsuario.loginname;
            objPlantilla.IV_USUARIO_CREA = ClsUsuario.nombres + "-" + ClsUsuario.apellidos;
            nSesion = objSesion.SaveTransaction(out cMensajes);
            if (!nSesion.HasValue || nSesion.Value <= 0)
            {
                this.Mostrar_Mensaje(2, string.Format("<b>Error! No se pudo generar el id de la sesión, por favor comunicarse con el departamento de IT de CGSA... {0}</b>", cMensajes));
                return;
            }


            //cabecera de transaccion

            objPlantilla = new VBS_CabeceraPlantilla();
            Session["Plantilla" + this.hf_BrowserWindowName.Value] = objPlantilla;

            _objTurnos = new VBS_TurnosDetalle();
            Session["ListTurnos" + this.hf_BrowserWindowName2.Value] = _objTurnos;
        }

        #endregion


        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            ViewStateUserKey = Session.SessionID;

        }


        protected void Page_Init(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Page.SslOn();
            }

            if (!Request.IsAuthenticated)
            {
                Response.Redirect("../login.aspx", false);

                return;
            }

            //this.IsAllowAccess();

            if (!Page.IsPostBack)
            {


                ClsUsuario = Page.Tracker();

            }

        }


        protected void Page_Load(object sender, EventArgs e)
        
        {
            try
            {


                if (!Page.IsPostBack)
                {
                    this.Carga_CboTipoCargas();
                    // this.Carga_CboTipoContenedor();
                    this.Crear_Sesion();
                    this.Carga_CboBloques();
                }
                else
                {


                }

                string tipoCargaId = Request.QueryString["tipoCargaId"];

                // Verificar si el parámetro tiene un valor válido y llamar a FiltrarDatosSegundoDropdown
                if (!string.IsNullOrEmpty(tipoCargaId))
                {
                    int idCarga = int.Parse(tipoCargaId);
                    FiltrarDatosSegundoDropdown(idCarga);
                }

            }
            catch (Exception ex)
            {
                this.Mostrar_Mensaje(1, string.Format("<b>Error! </b>{0}", ex.Message));
            }
        }

        private void FiltrarDatosSegundoDropdown(int idCarga)
        {
            try
            {
                List<VBS_ConsultarTipoContenedor> ListadoFiltrado = VBS_ConsultarTipoContenedor.ConsultarTipoContenedor(out cMensajes);

                var list = ListadoFiltrado.Where(x => x.Id_Carga == idCarga).ToList();

                // Crear una cadena de texto con los elementos del DropDownList
                StringBuilder sb = new StringBuilder();
                foreach (var item in list)
                {
                    sb.AppendFormat("<option value=\"{0}\">{1}</option>", item.Id_Contenedor, item.Desc_Contenedor);
                }

                // Generar la respuesta como cadena de texto
                string response = sb.ToString();

                // Enviar la respuesta al cliente
                Response.Write(response);
                Response.End();
            }
            catch (Exception ex)
            {
                var t = this.getUserBySesion();
                string Error = string.Format("Ha ocurrido un problema, por favor repórtelo con este código E00-{0}, gracias por entender.", csl_log.log_csl.save_log<Exception>(ex, "consulta", "FiltrarDatosSegundoDropdown", "Hubo un error al filtrar datos", t.loginname));
                this.Mostrar_Mensaje(1, Error);
            }
        }


        private void Carga_CboTipoCargas()
        {
            try
            {
                List<VBS_ConsultarTipoCargas> Listado = VBS_ConsultarTipoCargas.ConsultarTipoCargas(out cMensajes);

                var idcarga = Listado.FirstOrDefault().Id_Carga;

                Carga_CboTipoContenedor(idcarga);
                this.cboTipoCarga.DataSource = Listado;
                this.cboTipoCarga.DataTextField = "Desc_Carga";
                this.cboTipoCarga.DataValueField = "Id_Carga";
                this.cboTipoCarga.DataBind();

            }
            catch (Exception ex)
            {
                var t = this.getUserBySesion();
                string Error = string.Format("Ha ocurrido un problema, por favor repórtelo con este código E00-{0}, gracias por entender.", csl_log.log_csl.save_log<Exception>(ex, "consulta", "Carga_CboTipoCargas", "Hubo un error al cargar Tipo de cargas", t.loginname));
                this.Mostrar_Mensaje(1, Error);
            }
        }
        private void Carga_CboBloques()
        {
            try
            {
                List<VBS_ConsultarTipoBloques> Listado = VBS_ConsultarTipoBloques.ConsultarTipoBloques(out cMensajes);


                this.cboBloque.DataSource = Listado;
                this.cboBloque.DataTextField = "Codigo";
                this.cboBloque.DataValueField = "IdBloque";
                this.cboBloque.DataBind();

            }
            catch (Exception ex)
            {
                var t = this.getUserBySesion();
                string Error = string.Format("Ha ocurrido un problema, por favor repórtelo con este código E00-{0}, gracias por entender.", csl_log.log_csl.save_log<Exception>(ex, "consulta", "Carga_CboTipoCargas", "Hubo un error al cargar Tipo de cargas", t.loginname));
                this.Mostrar_Mensaje(1, Error);
            }
        }


        private void Carga_CboTipoContenedor(int idcarga)
        {
            try
            {
                List<VBS_ConsultarTipoContenedor> Listado = VBS_ConsultarTipoContenedor.ConsultarTipoContenedor(out cMensajes);

                var list = Listado.Where(x => x.Id_Carga == idcarga).ToList();

                this.cboTipoContenedor.DataSource = list;
                this.cboTipoContenedor.DataTextField = "Desc_Contenedor";
                this.cboTipoContenedor.DataValueField = "Id_Contenedor";
                this.cboTipoContenedor.DataBind();
            }
            catch (Exception ex)
            {
                var t = this.getUserBySesion();
                string Error = string.Format("Ha ocurrido un problema, por favor repórtelo con este código E00-{0}, gracias por entender.", csl_log.log_csl.save_log<Exception>(ex, "consulta", "Carga_CboTipoContenedor", "Hubo un error al cargar Tipo Contenedor", t.loginname));
                this.Mostrar_Mensaje(1, Error);
            }
        }


        [WebMethod]
        public static string GetCalendarEvents(int year, int month)
        {
            List<EventoCalendario> eventos = new List<EventoCalendario>();

            VBS_CabeceraPlantilla objPlantilla1 = new VBS_CabeceraPlantilla();
            var detalles = objPlantilla1.GetListaCalendario(year, month);

            if (detalles.Resultado == null)
            {
                return null;
            }
            else
            {
                foreach (Calendario_Turnos detalle in detalles.Resultado)
                {
                    EventoCalendario evento = new EventoCalendario();
                    evento.title = $"{detalle.Tipo_Cargas} - {detalle.Tipo_Contenedor} - {detalle.Total_Turnos} {"Disponible"} ({detalle.Total_Disponibles})"; // Combinar tipo_contenedor y total_turnos
                    evento.start = detalle.Dia.ToString("yyyy-MM-dd");
                    evento.end = detalle.Dia.AddDays(1).ToString("yyyy-MM-dd");
                    evento.idDetalle = detalle.Detalle;
                    if (detalle.TipoCargaId == 1)
                        evento.color = "#336BFF";
                    if (detalle.TipoCargaId == 2)
                        evento.color = "#17a2b8";
                    if (detalle.TipoCargaId == 3)
                        evento.color = "#dc3545";


                    eventos.Add(evento);
                }

                JavaScriptSerializer serializer = new JavaScriptSerializer();
                string json = serializer.Serialize(eventos.ToArray());
                return json;
            }

        }
        [WebMethod]
        public static string GetCalendarEventsImport(int year, int month)
        {
            List<EventoCalendario> eventos = new List<EventoCalendario>();

            VBS_CabeceraPlantilla objPlantilla1 = new VBS_CabeceraPlantilla();
            var detalles = objPlantilla1.GetListaCalendarioImport(year, month);

            if (detalles.Resultado == null)
            {
                return null;
            }
            else
            {
                foreach (Calendario_Turnos_Import detalle in detalles.Resultado)
                {
                    EventoCalendario evento = new EventoCalendario();
                    evento.title = $"{detalle.Bloque}  - {detalle.Total_Turnos} {"Disponible"} ({detalle.Total_Disponibles})"; // Combinar tipo_contenedor y total_turnos
                    evento.start = detalle.Dia.ToString("yyyy-MM-dd");
                    evento.end = detalle.Dia.AddDays(1).ToString("yyyy-MM-dd");
                    evento.color = "#336BFF";
                    evento.idDetalle = detalle.idBloque;
                  


                    eventos.Add(evento);
                }

                JavaScriptSerializer serializer = new JavaScriptSerializer();
                string json = serializer.Serialize(eventos.ToArray());
                return json;
            }

        }
        public class Detalle
        {
            public string secuencia { get; set; }
            public string tipoContenedor { get; set; }
            public string tipoCargas { get; set; }
            public string cantidad { get; set; }
            public string categoria { get; set; }
            public string tipoCargaId { get; set; }
            public string tipoContenedorId { get; set; }

        }
        public class DetalleImport
        {
            public string secuencia { get; set; }
            public string bloqueId { get; set; }
            public string tipoBloque { get; set; }
            public string frecuencia { get; set; }

        }

        [WebMethod]
        public static string GuardarDatosTabla1(string vigenciaInicial, string vigenciaFinal, int banderaDayClick, List<Detalle> detalles)
        {



            if (detalles == null)
            {
                throw new ArgumentNullException(nameof(detalles));
            }

            try
            {

                var ClsUsuario = usuario.Deserialize(HttpContext.Current.Session["control"].ToString());
                string fechaFormateadaInicial = string.Empty;
                string fechaFormateadaFinal = string.Empty;
                VBS_Calendario_Edit pageCalendario = new VBS_Calendario_Edit();
                if (banderaDayClick == 0)
                {
                    string formato = "ddd MMM dd yyyy HH:mm:ss 'GMT'zzz";
                    DateTimeOffset fechaVigenciaInicial = DateTimeOffset.ParseExact(vigenciaInicial, formato, CultureInfo.InvariantCulture);
                    DateTimeOffset fechaVigenciaFinal = DateTimeOffset.ParseExact(vigenciaFinal, formato, CultureInfo.InvariantCulture);

                    fechaVigenciaFinal = fechaVigenciaFinal.AddDays(-1);

                    fechaFormateadaInicial = fechaVigenciaInicial.ToString("yyyy-MM-dd");
                    fechaFormateadaFinal = fechaVigenciaFinal.ToString("yyyy-MM-dd");
                }
                else
                {
                    fechaFormateadaInicial = vigenciaInicial;
                    fechaFormateadaFinal = vigenciaFinal;
                }



                VBS_CabeceraPlantilla objCab = new VBS_CabeceraPlantilla();
                objCab.FECHA_CREACION = DateTime.Now;
                objCab.ESTADO = true;
                objCab.NOMBRE_PLANTILLA = ClsUsuario.nombres + "-" + ClsUsuario.apellidos;
                objCab.VIGENCIA_INICIAL = Convert.ToDateTime(fechaFormateadaInicial);
                objCab.VIGENCIA_FINAL = Convert.ToDateTime(fechaFormateadaFinal);
                objCab.USUARIO_CREACION = ClsUsuario.nombres + "-" + ClsUsuario.apellidos;


                System.Xml.Linq.XDocument XMLTurnos = new System.Xml.Linq.XDocument(new System.Xml.Linq.XDeclaration("1.0", "UTF-8", "yes"),
                    new System.Xml.Linq.XElement("TURNOS", from p in detalles.AsEnumerable().AsParallel()
                                                           select new System.Xml.Linq.XElement("DETALLE",
                                                           new System.Xml.Linq.XAttribute("SECUENCIA", p.secuencia),
                                                           new System.Xml.Linq.XAttribute("FECHA_CREACION", DateTime.Now),
                                                           new System.Xml.Linq.XAttribute("TIPO_CONTENEDOR", p.tipoContenedorId),
                                                           new System.Xml.Linq.XAttribute("TIPO_CARGAS", p.tipoCargaId),
                                                           new System.Xml.Linq.XAttribute("CANTIDAD", p.cantidad),
                                                           new System.Xml.Linq.XAttribute("ESTADO", 1),
                                                           new System.Xml.Linq.XAttribute("VIGENCIA_INICIAL", fechaFormateadaInicial),
                                                           new System.Xml.Linq.XAttribute("VIGENCIA_FINAL", fechaFormateadaFinal),
                                                           new System.Xml.Linq.XAttribute("flag", "I"))));
                objCab.xmlTurnos = XMLTurnos.ToString();

                var _cMensajes = String.Empty;

                var nProceso = objCab.SaveTransaction(out _cMensajes);



                var consultarTurnosGenerados = objCab.DetallePlantillas("", Convert.ToInt32(nProceso));
                if (consultarTurnosGenerados.Resultado != null)
                {
                    foreach (var ListDetalle in consultarTurnosGenerados.Resultado)
                    {

                        var consultaTurnosDetalle = objCab.VerificarCombinacionTipoCargaContenedor(Convert.ToInt32(ListDetalle.TIPO_CARGAS), ListDetalle.TIPO_CONTENEDOR,vigenciaInicial);

                        if (consultaTurnosDetalle.Resultado == null)
                        {
                            var Transportista = objCab.GuardarTurnos(Convert.ToInt32(nProceso),
                                ListDetalle.ID_DETALLEPLANTILLA,
                                ListDetalle.TIPO_CONTENEDOR, ListDetalle.TIPO_CARGAS,
                                ListDetalle.CANTIDAD,
                                ListDetalle.CATEGORIA,

                                ClsUsuario.nombres + "-" + ClsUsuario.apellidos,
                                Convert.ToDateTime(fechaFormateadaInicial),
                                Convert.ToDateTime(fechaFormateadaFinal));


                        }

                    }

                }
                else
                {

                }
                return "Datos guardados correctamente";
            }
            catch (Exception ex)
            {

                return "Error al procesar los detalles: " + ex.Message;
            }

        }

        [WebMethod]
        public static string GuardarDatosTablaImport(string vigenciaInicial, string vigenciaFinal, int banderaDayClick, List<DetalleImport> detalles)
        {
            if (detalles == null)
            {
                throw new ArgumentNullException(nameof(detalles));
            }

            try
            {

                var ClsUsuario = usuario.Deserialize(HttpContext.Current.Session["control"].ToString());
                string fechaFormateadaInicial = string.Empty;
                string fechaFormateadaFinal = string.Empty;
                VBS_Calendario_Edit pageCalendario = new VBS_Calendario_Edit();
                if (banderaDayClick == 0)
                {
                    string formato = "ddd MMM dd yyyy HH:mm:ss 'GMT'zzz";
                    DateTimeOffset fechaVigenciaInicial = DateTimeOffset.ParseExact(vigenciaInicial, formato, CultureInfo.InvariantCulture);
                    DateTimeOffset fechaVigenciaFinal = DateTimeOffset.ParseExact(vigenciaFinal, formato, CultureInfo.InvariantCulture);

                    fechaVigenciaFinal = fechaVigenciaFinal.AddDays(-1);

                    fechaFormateadaInicial = fechaVigenciaInicial.ToString("yyyy-MM-dd");
                    fechaFormateadaFinal = fechaVigenciaFinal.ToString("yyyy-MM-dd");
                }
                else
                {
                    fechaFormateadaInicial = vigenciaInicial;
                    fechaFormateadaFinal = vigenciaFinal;
                }

                VBS_CabeceraPlantilla objCab = new VBS_CabeceraPlantilla();

                foreach (var ListDetalle in detalles)
                {

                    var consultarTipoBloqueExiste = objCab.VerificarCombinacionTipoBloque(Convert.ToInt32(ListDetalle.bloqueId), ListDetalle.tipoBloque, vigenciaInicial);

                    if(consultarTipoBloqueExiste.Resultado == null)
                    {
                        var Transportista = objCab.GuardarTurnosImport(
                      ListDetalle.bloqueId,
                      ListDetalle.tipoBloque,
                      Convert.ToInt32(ListDetalle.frecuencia),

                      ClsUsuario.nombres + "-" + ClsUsuario.apellidos,
                        Convert.ToDateTime(fechaFormateadaInicial),
                       Convert.ToDateTime(fechaFormateadaFinal));
                    }
                  
                }


                return "Datos guardados correctamente";
            }
            catch (Exception ex)
            {

                return "Error al procesar los detalles: " + ex.Message;
            }
        }


        [WebMethod]
        public static string ConsultarEventos(int idDetalle, string start, string end)
        {
            try
            {
                DateTime fecha = DateTime.ParseExact(end, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                DateTime fechaRestada = fecha.AddDays(-1);
                string fechaRestadaString = fechaRestada.ToString("yyyy-MM-dd");

                VBS_CabeceraPlantilla objCab = new VBS_CabeceraPlantilla();
                var consultaTurnosDetalle = objCab.GetListaTurnosPorFechas(idDetalle, start, fechaRestadaString);



                //SqlDataSource SqlDataSource1 = new SqlDataSource();
                //SqlDataSource1.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["VBS"].ToString();
                //SqlDataSource1.SelectCommand = "exec VBS_CONSULTAR_TURNOS_DETALLE @ID_DETALLE_PLANTILLA = @idDetalle, @fechaStringDesde = @start, @fechaStringHasta = @end";
                //SqlDataSource1.SelectParameters.Add("idDetalle", idDetalle.ToString());
                //SqlDataSource1.SelectParameters.Add("start", start);
                //SqlDataSource1.SelectParameters.Add("end", end);
                //SqlDataSource1.DataBind();

                // Serializar los datos de eventos paginados a JSON
                string jsonEventos = JsonConvert.SerializeObject(consultaTurnosDetalle.Resultado);
                //dgvLiquidacion.DataSource = consultaTurnosDetalle.Resultado;
                //tablePagination.DataSource = consultaTurnosDetalle.Resultado;

                return jsonEventos;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar eventos en el servidor", ex);
            }
        }

        [WebMethod]
        public static string ConsultarEventosImport(int idDetalle, string start, string end)
        {
            try
            {
                DateTime fecha = DateTime.ParseExact(end, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                DateTime fechaRestada = fecha.AddDays(-1);
                string fechaRestadaString = fechaRestada.ToString("yyyy-MM-dd");

                VBS_CabeceraPlantilla objCab = new VBS_CabeceraPlantilla();
                var consultaTurnosDetalle = objCab.GetListaTurnosImportPorFechas(idDetalle, start, fechaRestadaString);

                var serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                serializer.MaxJsonLength = int.MaxValue;
                // Serializar los datos de eventos paginados a JSON
                string jsonEventos = JsonConvert.SerializeObject(consultaTurnosDetalle.Resultado);

                return jsonEventos;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar eventos en el servidor", ex);
            }
        }

        [WebMethod]
        public static string GuardarDatos(List<ActuEvento> datosTabla)
        {
            try
            {

                var ClsUsuario = usuario.Deserialize(HttpContext.Current.Session["control"].ToString());

                VBS_CabeceraPlantilla objCab = new VBS_CabeceraPlantilla();

                System.Xml.Linq.XDocument XMLTurnos = new System.Xml.Linq.XDocument(new System.Xml.Linq.XDeclaration("1.0", "UTF-8", "yes"),
                    new System.Xml.Linq.XElement("TURNOS", from p in datosTabla.AsEnumerable().AsParallel()
                                                           select new System.Xml.Linq.XElement("DETALLE",
                                                           new System.Xml.Linq.XAttribute("IDTURNO", Convert.ToInt64(p.idTurno)),
                                                           new System.Xml.Linq.XAttribute("CANTIDAD", p.cantidad),
                                                           new System.Xml.Linq.XAttribute("FECHAACTU", DateTime.Now),
                                                           new System.Xml.Linq.XAttribute("USUARIOMODIFI", ClsUsuario.nombres + "-" + ClsUsuario.apellidos),

                                                           new System.Xml.Linq.XAttribute("DISPONIBLE", p.disponible),

                                                           new System.Xml.Linq.XAttribute("ASIGNADOS", p.asignados),
                                                           new System.Xml.Linq.XAttribute("flag", "I"))));
                objCab.xmlTurnos = XMLTurnos.ToString();

                var _cMensajes = String.Empty;

                var nProceso = objCab.SaveTransactionUPDATE(out _cMensajes);
                if (nProceso > 0)
                {

                    return "success";
                }

                return "fail";
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

                return JsonConvert.SerializeObject(new { result = "error" });
            }
        }

        [WebMethod]
        public static string GuardarDatosImport(List<ActuEvento> datosTabla)
        {
            try
            {

                var ClsUsuario = usuario.Deserialize(HttpContext.Current.Session["control"].ToString());

                VBS_CabeceraPlantilla objCab = new VBS_CabeceraPlantilla();

                System.Xml.Linq.XDocument XMLTurnos = new System.Xml.Linq.XDocument(new System.Xml.Linq.XDeclaration("1.0", "UTF-8", "yes"),
                    new System.Xml.Linq.XElement("TURNOS", from p in datosTabla.AsEnumerable().AsParallel()
                                                           select new System.Xml.Linq.XElement("DETALLE",
                                                           new System.Xml.Linq.XAttribute("IDTURNO", Convert.ToInt64(p.idTurno)),
                                                           new System.Xml.Linq.XAttribute("CANTIDAD", p.cantidad),
                                                           new System.Xml.Linq.XAttribute("FECHAACTU", DateTime.Now),
                                                           new System.Xml.Linq.XAttribute("USUARIOMODIFI", ClsUsuario.nombres + "-" + ClsUsuario.apellidos),

                                                           new System.Xml.Linq.XAttribute("DISPONIBLE", p.disponible),

                                                           new System.Xml.Linq.XAttribute("ASIGNADOS", p.asignados),
                                                           new System.Xml.Linq.XAttribute("flag", "I"))));
                objCab.xmlTurnos = XMLTurnos.ToString();

                var _cMensajes = String.Empty;

                var nProceso = objCab.SaveTransactionUPDATEIMPORT(out _cMensajes);
                if (nProceso > 0)
                {

                    return "success";
                }

                return "fail";
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

                return JsonConvert.SerializeObject(new { result = "error" });
            }
        }



        [WebMethod]
        public static string GuardarDatosVacios(List<ActuEvento> datosTabla)
        {
            try
            {

                var ClsUsuario = usuario.Deserialize(HttpContext.Current.Session["control"].ToString());

                VBS_CabeceraPlantilla objCab = new VBS_CabeceraPlantilla();

                System.Xml.Linq.XDocument XMLTurnos = new System.Xml.Linq.XDocument(new System.Xml.Linq.XDeclaration("1.0", "UTF-8", "yes"),
                    new System.Xml.Linq.XElement("TURNOS", from p in datosTabla.AsEnumerable().AsParallel()
                                                           select new System.Xml.Linq.XElement("DETALLE",
                                                           new System.Xml.Linq.XAttribute("IDTURNO", Convert.ToInt64(p.idTurno)),
                                                           new System.Xml.Linq.XAttribute("CANTIDAD", p.cantidad),
                                                           new System.Xml.Linq.XAttribute("FECHAACTU", DateTime.Now),
                                                           new System.Xml.Linq.XAttribute("USUARIOMODIFI", ClsUsuario.nombres + "-" + ClsUsuario.apellidos),

                                                           new System.Xml.Linq.XAttribute("flag", "I"))));
                objCab.xmlTurnos = XMLTurnos.ToString();

                var _cMensajes = String.Empty;

                var nProceso = objCab.SaveTransactionUPDetalleVacios(out _cMensajes);
                if (nProceso > 0)
                {

                    return "success";
                }

                return "fail";
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

                return JsonConvert.SerializeObject(new { result = "error" });
            }
        }

        [WebMethod]
        public static string ConsultarEventosPorDia(string start)
        {
            try
            {

                List<EventoCalendario> eventos = new List<EventoCalendario>();


                DateTime fecha = DateTime.ParseExact(start, "yyyy-MM-dd", CultureInfo.InvariantCulture);

                string fechaRestadaString = fecha.ToString("yyyy-MM-dd");

                VBS_CabeceraPlantilla objCab = new VBS_CabeceraPlantilla();
                var consultaTurnosDetalle = objCab.GetListaTurnosPorDia(fechaRestadaString);

                if (consultaTurnosDetalle.Resultado != null)
                {
                    foreach (VBS_TurnosDetalle detalle in consultaTurnosDetalle.Resultado)
                    {
                        EventoCalendario evento = new EventoCalendario();
                        evento.title = $"{detalle.TipoCargas} - {detalle.TipoContenedor} - {detalle.Cantidad} {"Disponible"} - ({detalle.Disponible})"; // Combinar tipo_contenedor y total_turnos
                        evento.start = fechaRestadaString;
                        evento.end = fechaRestadaString;
                        if (detalle.TipoCargaId == 1)
                            evento.color = "#336BFF";
                        if (detalle.TipoCargaId == 2)
                            evento.color = "#17a2b8";
                        if (detalle.TipoCargaId == 3)
                            evento.color = "#dc3545";
                        evento.horario = detalle.Horario.ToString(@"hh\:mm");

                        eventos.Add(evento);
                    }

                }


                JavaScriptSerializer serializer = new JavaScriptSerializer();
                string json = serializer.Serialize(eventos.ToArray());

                // Serializar los datos de eventos paginados a JSON

                return json;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar eventos en el servidor", ex);
            }
        }

        [WebMethod]
        public static string ConsultarEventosPorDiaImport(string start)
        {
            try
            {

                List<EventoCalendario> eventos = new List<EventoCalendario>();


                DateTime fecha = DateTime.ParseExact(start, "yyyy-MM-dd", CultureInfo.InvariantCulture);

                string fechaRestadaString = fecha.ToString("yyyy-MM-dd");

                VBS_CabeceraPlantilla objCab = new VBS_CabeceraPlantilla();
                var consultaTurnosDetalle = objCab.GetListaTurnosPorDiaImport(fechaRestadaString);

                if (consultaTurnosDetalle.Resultado != null)
                {
                    foreach (VBS_TurnosDetalle_Import detalle in consultaTurnosDetalle.Resultado)
                    {
                        EventoCalendario evento = new EventoCalendario();
                        evento.title = $"{detalle.CodigoBloque}  - {detalle.Cantidad} {"Disponible"} - ({detalle.Disponible})"; // Combinar tipo_contenedor y total_turnos
                        evento.start = fechaRestadaString;
                        evento.end = fechaRestadaString;
                        evento.color = "#336BFF";

                        evento.horario = detalle.Horario.ToString(@"hh\:mm");

                        eventos.Add(evento);
                    } 

                }


                JavaScriptSerializer serializer = new JavaScriptSerializer();
                string json = serializer.Serialize(eventos.ToArray());

                // Serializar los datos de eventos paginados a JSON

                return json;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar eventos en el servidor", ex);
            }
        }

        [WebMethod]

        public static string ConsultarBookingCalendario(string fecha)
        {
            try
            {
                DataHelper obj = new DataHelper();

                var tablaNave = obj.GetTablaNaves(fecha);
                string jsonTablaNave = ConvertDataTableToJson(tablaNave);
                return jsonTablaNave;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar eventos en el servidor", ex);
            }
        }
        public static string ConvertDataTableToJson(DataTable dataTable)
        {
            string json = JsonConvert.SerializeObject(dataTable, Newtonsoft.Json.Formatting.Indented);
            return json;
        }

        [WebMethod]
        public static string ConsultarTablaExpoPorDia(string start)
        {
            try
            {

                List<EventoCalendario> eventos = new List<EventoCalendario>();


                DateTime fecha = DateTime.ParseExact(start, "yyyy-MM-dd", CultureInfo.InvariantCulture);

                string fechaRestadaString = fecha.ToString("yyyy-MM-dd");

                VBS_CabeceraPlantilla objCab = new VBS_CabeceraPlantilla();
                var consultaTurnosDetalle = objCab.GetTablaExpoPorDia(fechaRestadaString);

                if (consultaTurnosDetalle.Resultado != null)
                {
                    foreach (VBS_TurnosDetalle detalle in consultaTurnosDetalle.Resultado)
                    {
                        EventoCalendario evento = new EventoCalendario();
                        evento.title = $"{detalle.TipoCargas} - {detalle.TipoContenedor} - {detalle.Cantidad} {"Disponible"} - ({detalle.Disponible})"; // Combinar tipo_contenedor y total_turnos
                        evento.start = fechaRestadaString;
                        evento.end = fechaRestadaString;
                        evento.tipoCarga = detalle.TipoCargas;
                        evento.tipoContenedor = detalle.TipoContenedor;
                        evento.cantidad = detalle.Cantidad;
                        evento.tipoCargaId = detalle.TipoCargaId;
                        evento.tipoContenedorId = detalle.TipoContenedorId;

                        eventos.Add(evento);
                    }

                }


                JavaScriptSerializer serializer = new JavaScriptSerializer();
                string json = serializer.Serialize(eventos.ToArray());

                // Serializar los datos de eventos paginados a JSON

                return json;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar eventos en el servidor", ex);
            }
        }

        [WebMethod]
        public static string ConsultarTablaImportPorDia(string start)
        {
            try
            {

                List<EventoCalendario> eventos = new List<EventoCalendario>();

                DateTime fecha = DateTime.ParseExact(start, "yyyy-MM-dd", CultureInfo.InvariantCulture);

                string fechaRestadaString = fecha.ToString("yyyy-MM-dd");

                VBS_CabeceraPlantilla objCab = new VBS_CabeceraPlantilla();
                var consultaTurnosDetalle = objCab.GetTablaImportPorDia(fechaRestadaString);

                if (consultaTurnosDetalle.Resultado != null)
                {
                    foreach (VBS_TurnosDetalle_Import detalle in consultaTurnosDetalle.Resultado)
                    {
                        EventoCalendario evento = new EventoCalendario();
                        evento.title = $"{detalle.CodigoBloque}  - {detalle.Cantidad} {"Disponible"} - ({detalle.Disponible})"; // Combinar tipo_contenedor y total_turnos
                        evento.start = fechaRestadaString;
                        evento.end = fechaRestadaString;
                        evento.cantidad = detalle.Frecuencia;
                        evento.tipoBloqueId = detalle.idBloque;
                        evento.codigoBloque = detalle.CodigoBloque;

                        eventos.Add(evento);
                    }

                }


                JavaScriptSerializer serializer = new JavaScriptSerializer();
                string json = serializer.Serialize(eventos.ToArray());


                return json;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar eventos en el servidor", ex);
            }
        }

        [WebMethod]

        public static string GetDetalleVacios(string idTurno)
        {
            try
            {
                
                if (Convert.ToInt32(idTurno) > 0)
                {
                    VBS_CabeceraPlantilla objCab = new VBS_CabeceraPlantilla();

                    var consultarDetalle = objCab.ConsultarDetalleVacios(Convert.ToInt32(idTurno));

                    JavaScriptSerializer serializer = new JavaScriptSerializer();
                    string json = serializer.Serialize(consultarDetalle.Resultado.ToArray());


                    return json;
                }
                else
                {
                    throw new Exception("no existen datos a consultar");
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar eventos en el servidor", ex);
            }

         }



        #region "Gridview Cabecera"
        protected void tablePagination_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            //if (e.Row.RowType == DataControlRowType.DataRow)
            //{
            //    Button btnEditar = (Button)e.Row.FindControl("btnEditar");
            //    CheckBox Chk = (CheckBox)e.Row.FindControl("CHKPRO");
            //    string v_estado = DataBinder.Eval(e.Row.DataItem, "estado").ToString().Trim();
            //    long v_id = long.Parse(DataBinder.Eval(e.Row.DataItem, "idTarjaDet").ToString().Trim());

            //    if (v_id <= 0)
            //    {
            //        btnEditar.Enabled = false;
            //    }
            //    else
            //    {
            //        if (v_estado != "NUE")
            //        {
            //            Chk.Checked = true;
            //            e.Row.ForeColor = System.Drawing.Color.DarkSlateBlue;
            //        }
            //    }

            //    //this.Actualiza_Panele_Detalle();
            //}
        }
        protected void tablePagination_RowCommand(object source, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Editar")
            {
                /*long v_ID = long.Parse(e.CommandArgument.ToString());
                if (v_ID <= 0) { return; }
                objCabecera = Session["TransaccionTarjaCab" + this.hf_BrowserWindowName.Value] as tarjaCab;
                if (objCabecera == null) { return; }

                var oDet = objCabecera.Detalle.Where(a => a.idTarjaDet == v_ID).FirstOrDefault();
                Session["TransaccionTarjaDet" + this.hf_BrowserWindowName.Value] = oDet;

                txtBL.Text = oDet.bl;
                txtmrnDet.Text = oDet.mrn;
                txtmsnDet.Text = oDet.msn;
                txthsnDet.Text = oDet.hsn;
                txtRucConsignatario.Text = oDet.idConsignatario;
                txtConsignatario.Text = oDet.Consignatario;
                txtProductoEcuapass.Text = oDet.productoEcuapass;
                txtCantidad.Text = oDet.cantidad.ToString();
                txtKilos.Text = oDet.kilos.ToString();
                txtCubicaje.Text = oDet.cubicaje.ToString();
                txtTonelaje.Text = oDet.tonelaje.ToString();
                txtDescripcion.Text = oDet.descripcion;
                txtContenido.Text = oDet.contenido;
                txtobservacion.Text = oDet.observacion;
                cmbImo.SelectedValue = oDet.imo;

                cmbProducto.SelectedValue = oDet.idProducto.ToString();
                if (cmbProducto.SelectedValue == "0")
                {
                    cmbManiobra.SelectedValue = "0";
                    cmbItem.SelectedValue = "0";
                    cmbCondicion.SelectedValue = "0";
                }
                else
                {
                    cmbManiobra.SelectedValue = oDet.producto?.Maniobra.id.ToString();
                    cmbItem.SelectedValue = oDet.producto?.Items.id.ToString();
                    cmbCondicion.SelectedValue = oDet.idCondicion.ToString();
                }
                nave oNave;
                try { oNave = nave.GetNave(oDet.tarjaCab.idNave); } catch { Response.Redirect("../login.aspx", false); return; }

                if (string.IsNullOrEmpty(oNave.ata?.ToString()))
                {
                    //se valida que el Bl no se encuentre en status PRE - CON - DES
                    var oDeta = tarjaDet.GetTarjaDet(long.Parse(oDet.idTarjaDet.ToString()));
                    if (oDeta.estado == "NUE" || oDeta.estado == "ACT")
                    {
                        this.btnActualizar.Attributes.Remove("disabled");
                    }
                    else
                    {
                        this.btnActualizar.Attributes["disabled"] = "disabled";
                        this.Alerta("No se puede actualizar, el BL se encuentra en status " + oDeta.Estados.nombre);
                        this.Mostrar_MensajeDet(string.Format("<i class='fa fa-warning'></i><b> Informativo! </b>{0}", "No se puede actualizar, el BL se encuentra en status " + oDeta.Estados.nombre));
                        this.txtBL.Focus();

                        UPEDIT.Update();
                        return;
                    }
                }
                else
                {
                    this.btnActualizar.Attributes["disabled"] = "disabled";
                    this.Alerta("La nave ha arribado a la terminal y consta con DRM. Favor comunicarse a las casillas de multipropósito o redireccionar su requerimiento a breakbulk@cgsa.com.ec y dataentrycfs@cgsa.com.ec");
                    this.Mostrar_MensajeDet(string.Format("<i class='fa fa-warning'></i><b> Informativo! </b>{0}", "La nave ha arribado a la terminal y consta con DRM. Favor comunicarse a las casillas de multipropósito o redireccionar su requerimiento a breakbulk@cgsa.com.ec y dataentrycfs@cgsa.com.ec"));
                    this.txtBL.Focus();
                    UPEDIT.Update();
                    return;
                }

                msjErrorDetalle.Visible = false;
                UPEDIT.Update();*/
            }
        }
        protected void tablePagination_PreRender(object sender, EventArgs e)
        {
            try
            {
                /*
                if (hidden-table-info2.Rows.Count > 0)
                {
                    tablePagination.UseAccessibleHeader = true;
                    // Agrega la sección THEAD y TBODY.
                    tablePagination.HeaderRow.TableSection = TableRowSection.TableHeader;

                    // Agrega el elemento TH en la fila de encabezado.               
                    // Agrega la sección TFOOT. 
                    //tablePagination.FooterRow.TableSection = TableRowSection.TableFooter;
                }
                */
            }
            catch (Exception ex)
            {
                //this.Mostrar_Mensaje(string.Format("<b>Error! </b>Lo sentimos, algo salió mal. Estamos trabajando para solucionarlo lo más pronto posible..{0}", ex.Message));
            }

        }
        protected void tablePagination_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {/*
            try
            {
                objCabecera = Session["TransaccionTarjaCab" + this.hf_BrowserWindowName.Value] as tarjaCab;

                if (objCabecera == null)
                {
                    this.Mostrar_Mensaje(string.Format("<b>Informativo! </b>Debe generar la consulta"));
                    return;
                }
                else
                {
                    tablePagination.PageIndex = e.NewPageIndex;
                    tablePagination.DataSource = objCabecera.Detalle;
                    tablePagination.DataBind();
                    this.Actualiza_Panele_Detalle();
                }
            }
            catch (Exception ex)
            {
                this.Mostrar_Mensaje(string.Format("<b>Error! </b>Lo sentimos, algo salió mal. Estamos trabajando para solucionarlo lo más pronto posible..{0}", ex.Message));
            }*/
        }
        protected void tablePagination_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (Response.IsClientConnected)
            {
                try
                {
                    if (HttpContext.Current.Request.Cookies["token"] == null)
                    {
                        System.Web.Security.FormsAuthentication.SignOut();
                        Session.Clear();
                        System.Web.Security.FormsAuthentication.RedirectToLoginPage();
                        return;
                    }

                    //var ClsUsuario = usuario.Deserialize(HttpContext.Current.Session["control"].ToString());

                    if (e.CommandArgument == null)
                    {
                        //this.Mostrar_Mensaje(string.Format("<i class='fa fa-warning'></i><b> Error! </b>Lo sentimos, algo salió mal. Estamos trabajando para solucionarlo lo más pronto posible....{0}", "no existen argumentos"));
                        return;
                    }

                    Int64 id;
                    var t = e.CommandArgument.ToString();
                    if (!Int64.TryParse(t, out id))
                    {
                        //this.Mostrar_Mensaje(string.Format("<i class='fa fa-warning'></i><b> Error! </b>Lo sentimos, algo salió mal. Estamos trabajando para solucionarlo lo más pronto posible....{0}", "no se puede convertir id"));
                        return;
                    }

                    if (e.CommandName == "Modificar")
                    {
                        //PagoAsignado pago = new PagoAsignado(id, ClsUsuario.loginname.Trim());
                        /*var Resultado = productos.GetProducto(int.Parse(id.ToString()));
                        if (Resultado != null)
                        {
                            oProducto = Resultado;
                            txtNombre.Text = Resultado.nombre;
                            cmbEstado.SelectedValue = Resultado.estado.ToString();
                            cmbManiobra.SelectedValue = Resultado.Maniobra.id.ToString();
                            cmbItem.SelectedValue = Resultado.Items.id.ToString();
                        }
                        else
                        {
                            oProducto = null;
                            this.Mostrar_Mensaje(1, string.Format("<i class='fa fa-warning'></i><b> Error! </b>Se presentaron las siguientes observaciones: {0} ", "No se pudo editar para modificar"));
                            return;
                        }*/
                        //Actualiza_Paneles();
                    }
                }
                catch (Exception ex)
                {
                    //lm = SqlConexion.Cls_Conexion.LogEvent<Exception>(Page.User.Identity.Name, nameof(tablePagination_ItemCommand), "BorrarAsignacion", false, null, null, ex.StackTrace, ex);
                    //OError = string.Format("{0} {1}", string.Format("Excepcion no.{0}", lm), string.Format("Reporte el número el siguiente ticket de servicio:{0}", lm.HasValue ? lm : -2));
                    //this.Mostrar_Mensaje(string.Format("<i class='fa fa-warning'></i><b> Error! </b>Lo sentimos, algo salió mal. Estamos trabajando para solucionarlo lo más pronto posible....{0}", OError));
                    return;
                }
            }
        }

        #endregion

        protected void Txtcantidad_TextChanged(object sender, EventArgs e)
        {

        }
        protected void tablePagination_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {

        }
    }

}