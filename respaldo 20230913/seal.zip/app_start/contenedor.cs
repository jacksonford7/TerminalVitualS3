﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CSLSite.app_start
{
    public class contenedor
    {

        public Int64 gkey { get; set; }
        public string id { get; set; } //nombre
        public string categoria { get; set; } //trafico
        public string freightKind { get; set; } 

    }
}